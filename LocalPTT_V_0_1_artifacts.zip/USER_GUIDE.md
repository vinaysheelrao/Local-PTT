# LocalPTT User Guide

1. Install the same APK on at least two devices.
2. Connect both devices to the same Wi-Fi or hotspot.
3. Open LocalPTT.
4. Grant notification, microphone, and local-network permissions as requested.
5. On one device select Create Room.
6. On the other device select Join Room.
7. Select the discovered room.
8. Enter the host PIN.
9. Hold the PTT button to speak.
10. Release the button to stop transmitting.
11. Optionally enable the floating control.

If discovery does not find the host, enter the host IP address and control port shown on the host screen.
