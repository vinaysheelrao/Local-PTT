# Privacy

LocalPTT uses no cloud account, analytics SDK, advertising SDK, Firebase backend, hosted WebSocket, or external server.

Voice is captured only while push-to-talk is actively held and after the room host grants the speaking floor. Voice is encoded to Opus and transported over the selected local network. Voice is not recorded to app storage and no PCM or Opus audio files are written.

V_0_1 is designed for trusted local networks. It should not be represented as suitable for hostile public Wi-Fi unless transport encryption is added and verified.
