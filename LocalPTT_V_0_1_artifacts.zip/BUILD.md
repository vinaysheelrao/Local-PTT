# Build LocalPTT

The project is an Android Studio compatible Gradle Kotlin DSL project.

This Codex run configured local build tools under `work/toolchains`:

- Temurin JDK 17
- Android command-line tools
- Android SDK platform 36
- Android build-tools 36.1.0
- Android NDK 28.2.13676358
- CMake 3.22.1

Run:

```powershell
.\build_apk.ps1
```

The script prefers the generated Gradle wrapper and falls back to a cached Gradle 9.2.1 distribution. It expects the local toolchain above or equivalent tools installed and discoverable through `JAVA_HOME` and `ANDROID_HOME`. The APK output is copied to:

```text
dist/LocalPTT_V_0_1.apk
```

The debug signing key is used for V_0_1 sideload evaluation.
