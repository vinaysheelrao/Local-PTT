# Changelog

## 0.1.0

- Initial LocalPTT V_0_1 Android app.
- Host and client roles in one APK.
- NSD room advertisement and discovery with manual IP fallback.
- Length-prefixed JSON control protocol.
- UDP Opus packet transport with JNI libopus build from official source.
- Foreground radio service, persistent notification, in-app PTT, optional overlay PTT.
- Unit tests for protocol, UDP packet validation, floor state, jitter, auth, and backoff.
