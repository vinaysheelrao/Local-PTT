param(
    [string]$ApkPath = "$(Split-Path -Parent $MyInvocation.MyCommand.Path)\dist\LocalPTT_V_0_1.apk"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$LocalAdb = Join-Path $Root "work\toolchains\android-sdk\platform-tools\adb.exe"
$Adb = if (Test-Path $LocalAdb) { $LocalAdb } else { (Get-Command adb -ErrorAction SilentlyContinue).Source }

if (!$Adb) { throw "ADB is not available. Install Android platform-tools or run build_apk.ps1 first." }
if (!(Test-Path $ApkPath)) { throw "APK not found: $ApkPath" }

$devices = & $Adb devices | Select-String -Pattern "`tdevice$"
if ($devices.Count -eq 0) { throw "No connected authorized Android device found by adb." }

Write-Host "Installing $ApkPath"
& $Adb install -r $ApkPath
if ($LASTEXITCODE -ne 0) { throw "ADB install failed with exit code $LASTEXITCODE" }
Write-Host "Install succeeded."
