# Known Limitations

- Devices must be mutually reachable over the local network.
- Some routers or hotspots may isolate clients.
- NSD behavior varies by manufacturer.
- Some manufacturers aggressively terminate background services.
- Platform noise suppression and echo cancellation vary by device.
- V_0_1 supports one active speaker at a time.
- Remote operation across unrelated internet networks is outside V_0_1.
- Bluetooth routing may depend on Android and device audio policy.
- Public-network security is limited because transport encryption is not implemented.
- The current implementation has automated JVM coverage for core protocol and state logic, but physical two-device audio validation must be performed on actual Android devices.
