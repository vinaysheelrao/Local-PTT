# Test Matrix

## Automated

- Control-message framing
- Maximum control-message size
- Invalid JSON rejection
- UDP packet encode/decode
- Invalid audio header rejection
- Payload-length validation
- Sequence duplicate detection
- Sequence rollover
- Jitter-buffer bounds
- Stream reset
- Floor request/grant/denial/release
- Delayed grant after button release
- Overlay-equivalent cancellation via release transition
- Room PIN generation
- Authentication rate limiting
- Reconnection backoff
- Launcher Activity smoke test source is present for instrumented execution

## Manual Checklist

1. Android device A creates a room.
2. Android device B discovers it.
3. B joins with an incorrect PIN.
4. B joins with the correct PIN.
5. A transmits to B.
6. B transmits to A.
7. Both press PTT nearly simultaneously.
8. The losing requester receives busy feedback.
9. A releases the button normally.
10. A moves a finger outside the button, causing cancellation.
11. A backgrounds the application.
12. A transmits using the floating control.
13. B receives while its screen is off.
14. The network is disconnected and restored.
15. The host closes the room.
16. The client app is force-closed during transmission.
17. Overlay permission is denied.
18. Microphone permission is denied.
19. Notification permission is denied.
20. Local-network permission is denied on a supported Android version.
21. Noise suppression is unavailable.
22. Wired or Bluetooth audio routing is changed during connection.
23. Thirty minutes of connected idle operation.
24. At least 100 repeated PTT press-and-release cycles.

Manual device tests were not executed in this build environment unless separately recorded in the completion report.
