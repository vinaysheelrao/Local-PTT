# Architecture

LocalPTT uses a hub-and-spoke LAN design. The host Android device owns the TCP control server, room authentication, peer registry, speaking-floor lease, NSD advertisement, and UDP packet forwarding. Clients keep a persistent TCP control connection and a UDP receive socket.

Long-lived radio work is owned by `RadioForegroundService`. `MainActivity` binds to the service and only handles UI, permissions, and user actions.

Important packages:

- `network.control`: length-prefixed JSON control protocol, host/client sessions, heartbeat, floor messages.
- `network.audio`: compact UDP audio packet format and sequence validation.
- `audio.codec`: JNI bridge to official libopus.
- `audio.capture`: `AudioRecord` capture and Opus encode while PTT is granted.
- `audio.playback`: streaming `AudioTrack` playback and bounded jitter buffering.
- `discovery`: Android `NsdManager` advertisement and discovery.
- `overlay`: optional system overlay PTT button.
- `floor`: testable floor state machine.
