# Audio Pipeline

Capture starts only after a local PTT press receives `FLOOR_GRANTED`. `AudioRecord` uses `VOICE_COMMUNICATION`, mono 16-bit PCM, 20 ms frames, and prefers 48000 Hz with a 16000 Hz fallback.

The JNI Opus wrapper creates an `OPUS_APPLICATION_VOIP` encoder with VBR, in-band FEC, packet-loss expectation, and an approximate 24 kbps bitrate. Platform `NoiseSuppressor`, `AcousticEchoCanceler`, and `AutomaticGainControl` are attached when available and enabled.

Playback uses one streaming `AudioTrack` per radio session and a bounded jitter buffer. Local playback is muted while the device is transmitting to reduce feedback.

Audio is not written to files.
