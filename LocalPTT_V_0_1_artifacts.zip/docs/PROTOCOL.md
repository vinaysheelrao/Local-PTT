# Control and Audio Protocol

## TCP Control

Every control frame is a four-byte big-endian payload length followed by a UTF-8 JSON object. Maximum frame size is 32768 bytes.

Each JSON message contains:

- `protocolVersion`
- `messageType`
- `messageId`
- `timestamp`
- `senderNodeId`
- `sessionId`
- `payload`

Implemented message types include `HELLO`, `AUTH_RESULT`, `WELCOME`, `PEER_LIST`, `PEER_JOINED`, `PEER_LEFT`, `HEARTBEAT`, `HEARTBEAT_ACK`, `FLOOR_REQUEST`, `FLOOR_GRANTED`, `FLOOR_DENIED`, `FLOOR_RENEW`, `FLOOR_RELEASE`, `FLOOR_REVOKED`, `ROOM_STATUS`, `HOST_SHUTDOWN`, `CLIENT_DISCONNECT`, and `ERROR`.

## UDP Audio

UDP packets use a fixed binary header:

- Magic `LPTT`
- Version
- Flags
- Session UUID
- Sender numeric node identifier
- Stream identifier
- Sequence number
- Audio timestamp
- Codec identifier
- Sample-rate identifier
- Payload length
- Opus payload

Flags include `STREAM_START`, `AUDIO_FRAME`, `STREAM_END`, and `FEC_AVAILABLE`.
