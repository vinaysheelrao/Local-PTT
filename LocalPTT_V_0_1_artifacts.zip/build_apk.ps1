param(
    [switch]$SkipLint
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Toolchain = Join-Path $Root "work\toolchains"
$JavaHome = Join-Path $Toolchain "jdk-17"
$AndroidHome = Join-Path $Toolchain "android-sdk"
$Wrapper = Join-Path $Root "gradlew.bat"
$CachedGradle = Get-ChildItem -Path "$env:USERPROFILE\.gradle\wrapper\dists\gradle-9.2.1-bin" -Recurse -Filter "gradle.bat" -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -like "*gradle-9.2.1*bin*" } |
    Select-Object -First 1
$GradleCommand = if (Test-Path $Wrapper) { $Wrapper } elseif ($null -ne $CachedGradle) { $CachedGradle.FullName } else { $null }

if (!(Test-Path "$JavaHome\bin\java.exe")) { throw "Missing JDK 17 at $JavaHome" }
if (!(Test-Path "$AndroidHome\platforms\android-36\android.jar")) { throw "Missing Android SDK platform android-36 under $AndroidHome" }
if ($null -eq $GradleCommand) { throw "Missing Gradle wrapper or cached Gradle 9.2.1 distribution. Install Gradle or run through Android Studio." }

$env:JAVA_HOME = $JavaHome
$env:ANDROID_HOME = $AndroidHome
$env:ANDROID_SDK_ROOT = $AndroidHome
$env:PATH = "$JavaHome\bin;$AndroidHome\platform-tools;$AndroidHome\build-tools\36.1.0;$env:PATH"

function Run-Stage($Name, [scriptblock]$Block) {
    Write-Host "== $Name =="
    & $Block
    if ($LASTEXITCODE -ne 0) { throw "$Name failed with exit code $LASTEXITCODE" }
}

Push-Location $Root
try {
    Run-Stage "Gradle clean" { & $GradleCommand "--no-daemon" "clean" }
    Run-Stage "Unit tests" { & $GradleCommand "--no-daemon" "test" }
    if (!$SkipLint) {
        Run-Stage "Lint" { & $GradleCommand "--no-daemon" "lint" }
    }
    Run-Stage "Assemble debug APK" { & $GradleCommand "--no-daemon" "assembleDebug" }

    $Apk = Join-Path $Root "app\build\outputs\apk\debug\app-debug.apk"
    if (!(Test-Path $Apk)) { throw "APK not found at $Apk" }
    if ((Get-Item $Apk).Length -le 0) { throw "APK has zero size" }

    $ApkSigner = Join-Path $AndroidHome "build-tools\36.1.0\apksigner.bat"
    if (Test-Path $ApkSigner) {
        Run-Stage "APK signature verify" { & $ApkSigner "verify" "--verbose" $Apk }
    } else {
        Write-Warning "apksigner not available; skipping signature verification."
    }

    $Aapt = Join-Path $AndroidHome "build-tools\36.1.0\aapt.exe"
    if (Test-Path $Aapt) {
        Write-Host "== APK badging =="
        & $Aapt "dump" "badging" $Apk | Select-String -Pattern "package:|sdkVersion|targetSdkVersion|native-code|uses-permission" | ForEach-Object { $_.Line }
    }

    $Dist = Join-Path $Root "dist"
    New-Item -ItemType Directory -Force -Path $Dist | Out-Null
    $FinalApk = Join-Path $Dist "LocalPTT_V_0_1.apk"
    Copy-Item -LiteralPath $Apk -Destination $FinalApk -Force
    $Hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $FinalApk).Hash.ToLowerInvariant()
    Set-Content -LiteralPath "$FinalApk.sha256" -Value "$Hash  LocalPTT_V_0_1.apk" -Encoding ASCII

    Write-Host "Final APK: $FinalApk"
    Write-Host "SHA-256: $Hash"
} finally {
    Pop-Location
}
