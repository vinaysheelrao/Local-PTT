# Licenses

LocalPTT application source in this workspace is provided for functional evaluation.

Third-party dependencies:

- Android Gradle Plugin, Kotlin, Android SDK/NDK, CMake, AndroidX Test, JUnit, kotlinx.coroutines, and org.json are used under their respective upstream licenses.
- libopus 1.6.1 source is vendored under `third_party/opus` from the official Opus/Xiph release archive. Preserve upstream copyright and license notices in that directory when redistributing.

No analytics, advertising, telemetry, cloud account, or crash reporting SDK is included.
