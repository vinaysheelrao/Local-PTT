# Install LocalPTT

## Sideload

1. Copy or share `dist/LocalPTT_V_0_1.apk` to the Android device.
2. Enable installation from the file manager or browser source when Android asks.
3. Open the APK and install.

## ADB

```powershell
.\install_apk.ps1
```

Or manually:

```powershell
adb install -r dist\LocalPTT_V_0_1.apk
```

## Permissions

Grant microphone permission before using PTT. Grant notification permission so Android can show the foreground Radio Mode notification. On Android versions that expose local network permission, grant it for LAN sockets and room discovery.

Overlay permission is optional. Choose Enable Floating PTT in the app, then allow display over other apps in Android settings.

## Network Requirement

All devices must be mutually reachable on the same local network. Guest Wi-Fi, client isolation, VPN policy, or restrictive hotspot firmware may block discovery or peer traffic.

## Battery Management

Radio Mode uses a foreground service. Some manufacturers still stop background services under aggressive battery profiles. If receiving stops when the screen is off, allow LocalPTT unrestricted battery usage in Android settings.
