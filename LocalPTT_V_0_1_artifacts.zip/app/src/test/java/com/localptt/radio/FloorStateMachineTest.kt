package com.localptt.radio

import com.localptt.radio.floor.FloorAction
import com.localptt.radio.floor.FloorStateMachine
import com.localptt.radio.floor.RadioState
import org.junit.Assert.assertEquals
import org.junit.Test

class FloorStateMachineTest {
    @Test
    fun pttStartsOnlyAfterGrant() {
        val floor = FloorStateMachine()
        floor.connected()
        assertEquals(FloorAction.REQUEST_FLOOR, floor.pressPtt())
        assertEquals(RadioState.REQUESTING_FLOOR, floor.state)
        assertEquals(FloorAction.START_CAPTURE, floor.grant("me"))
        assertEquals(RadioState.TRANSMITTING, floor.state)
    }

    @Test
    fun delayedGrantAfterReleaseDoesNotStartCapture() {
        val floor = FloorStateMachine()
        floor.connected()
        floor.pressPtt()
        assertEquals(FloorAction.STOP_AND_RELEASE, floor.releasePtt())
        assertEquals(FloorAction.RELEASE_FLOOR, floor.grant("me"))
        assertEquals(RadioState.CONNECTED_IDLE, floor.state)
    }

    @Test
    fun cancellationStopsTransmitting() {
        val floor = FloorStateMachine()
        floor.connected()
        floor.pressPtt()
        floor.grant("me")
        assertEquals(FloorAction.STOP_AND_RELEASE, floor.releasePtt())
        assertEquals(RadioState.CONNECTED_IDLE, floor.state)
    }

    @Test
    fun denialMovesToBusy() {
        val floor = FloorStateMachine()
        floor.connected()
        floor.pressPtt()
        assertEquals(FloorAction.STOP_CAPTURE, floor.deny("other"))
        assertEquals(RadioState.BUSY, floor.state)
        assertEquals("other", floor.currentSpeaker)
    }
}
