package com.localptt.radio

import com.localptt.radio.audio.jitter.JitterBuffer
import com.localptt.radio.audio.jitter.PollResult
import com.localptt.radio.network.audio.AudioConstants
import com.localptt.radio.network.audio.UdpAudioPacket
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class JitterBufferTest {
    private fun packet(seq: Long, stream: Int = 1) = UdpAudioPacket(
        flags = AudioConstants.FLAG_AUDIO_FRAME,
        sessionId = UUID.randomUUID(),
        senderNodeId = 1,
        streamId = stream,
        sequence = seq,
        audioTimestamp = seq,
        payload = byteArrayOf(seq.toByte())
    )

    @Test
    fun reordersLimitedOutOfOrderPackets() {
        val buffer = JitterBuffer(capacity = 4)
        buffer.offer(packet(2))
        buffer.offer(packet(1))
        val first = buffer.poll()
        assertTrue(first is PollResult.Packet)
        assertEquals(2, (first as PollResult.Packet).packet.sequence)
    }

    @Test
    fun reportsMissingWhenBufferIsFull() {
        val buffer = JitterBuffer(capacity = 2)
        buffer.offer(packet(10))
        buffer.offer(packet(12))
        assertTrue(buffer.poll() is PollResult.Packet)
        assertTrue(buffer.poll() is PollResult.Missing)
    }

    @Test
    fun resetsOnNewStream() {
        val buffer = JitterBuffer(capacity = 4)
        buffer.offer(packet(1, stream = 1))
        buffer.offer(packet(100, stream = 2))
        val result = buffer.poll()
        assertTrue(result is PollResult.Packet)
        assertEquals(100, (result as PollResult.Packet).packet.sequence)
    }
}
