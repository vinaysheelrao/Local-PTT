package com.localptt.radio

import com.localptt.radio.network.control.ReconnectionBackoff
import com.localptt.radio.room.AuthRateLimiter
import com.localptt.radio.room.RoomPin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthAndBackoffTest {
    @Test
    fun pinIsSixDigits() {
        val pin = RoomPin.generate()
        assertTrue(pin.matches(Regex("\\d{6}")))
    }

    @Test
    fun authRateLimiterBlocksAfterFailures() {
        val limiter = AuthRateLimiter(maxAttempts = 2, windowMillis = 1000)
        assertTrue(limiter.recordFailure("addr", now = 0))
        assertTrue(limiter.recordFailure("addr", now = 10))
        assertFalse(limiter.canAttempt("addr", now = 20))
        assertTrue(limiter.canAttempt("addr", now = 2000))
    }

    @Test
    fun backoffCapsAtMaximumStepAndResets() {
        val backoff = ReconnectionBackoff()
        assertEquals(500, backoff.nextDelayMillis())
        assertEquals(1000, backoff.nextDelayMillis())
        assertEquals(2000, backoff.nextDelayMillis())
        assertEquals(4000, backoff.nextDelayMillis())
        assertEquals(8000, backoff.nextDelayMillis())
        assertEquals(8000, backoff.nextDelayMillis())
        backoff.reset()
        assertEquals(500, backoff.nextDelayMillis())
    }
}
