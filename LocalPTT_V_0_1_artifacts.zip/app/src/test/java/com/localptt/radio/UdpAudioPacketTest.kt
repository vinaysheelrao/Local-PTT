package com.localptt.radio

import com.localptt.radio.network.audio.AudioConstants
import com.localptt.radio.network.audio.SequenceDecision
import com.localptt.radio.network.audio.SequenceTracker
import com.localptt.radio.network.audio.UdpAudioPacket
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.util.UUID

class UdpAudioPacketTest {
    @Test
    fun roundTripAudioPacket() {
        val packet = UdpAudioPacket(
            flags = AudioConstants.FLAG_AUDIO_FRAME,
            sessionId = UUID.randomUUID(),
            senderNodeId = 42,
            streamId = 7,
            sequence = 9,
            audioTimestamp = 1234,
            payload = byteArrayOf(1, 2, 3)
        )
        val decoded = UdpAudioPacket.decode(packet.encode())
        assertEquals(packet.streamId, decoded.streamId)
        assertEquals(packet.sequence, decoded.sequence)
        assertArrayEquals(packet.payload, decoded.payload)
    }

    @Test
    fun rejectsBadMagic() {
        val bytes = UdpAudioPacket(
            flags = AudioConstants.FLAG_AUDIO_FRAME,
            sessionId = UUID.randomUUID(),
            senderNodeId = 1,
            streamId = 1,
            sequence = 1,
            audioTimestamp = 1,
            payload = byteArrayOf(1)
        ).encode()
        bytes[0] = 0
        assertThrows(IllegalArgumentException::class.java) { UdpAudioPacket.decode(bytes) }
    }

    @Test
    fun rejectsPayloadLengthMismatch() {
        val bytes = UdpAudioPacket(
            flags = AudioConstants.FLAG_AUDIO_FRAME,
            sessionId = UUID.randomUUID(),
            senderNodeId = 1,
            streamId = 1,
            sequence = 1,
            audioTimestamp = 1,
            payload = byteArrayOf(1)
        ).encode()
        val shorter = bytes.copyOf(bytes.size - 1)
        assertThrows(IllegalArgumentException::class.java) { UdpAudioPacket.decode(shorter) }
    }

    @Test
    fun sequenceTrackerHandlesDuplicatesAndRollover() {
        val tracker = SequenceTracker(window = 8)
        assertEquals(SequenceDecision.ACCEPT, tracker.accept(0xFFFF_FFFEL))
        assertEquals(SequenceDecision.ACCEPT, tracker.accept(0xFFFF_FFFFL))
        assertEquals(SequenceDecision.ACCEPT, tracker.accept(0))
        assertEquals(SequenceDecision.DUPLICATE, tracker.accept(0))
        assertEquals(SequenceDecision.DUPLICATE, tracker.accept(0xFFFF_FFFFL))
    }
}
