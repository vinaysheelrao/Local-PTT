package com.localptt.radio

import com.localptt.radio.network.control.ControlMessage
import com.localptt.radio.network.control.ControlProtocol
import com.localptt.radio.network.control.MessageType
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

class ControlProtocolTest {
    @Test
    fun roundTripLengthPrefixedMessage() {
        val message = ControlMessage(
            messageType = MessageType.HELLO,
            senderNodeId = "node-a",
            sessionId = "session",
            payload = JSONObject().put("nodeName", "A")
        )
        val encoded = ControlProtocol.encode(message)
        val decoded = ControlProtocol.read(ByteArrayInputStream(encoded))
        assertEquals(MessageType.HELLO, decoded.messageType)
        assertEquals("node-a", decoded.senderNodeId)
        assertEquals("A", decoded.payload.getString("nodeName"))
    }

    @Test
    fun rejectsOversizedMessage() {
        val payload = JSONObject().put("blob", "x".repeat(ControlProtocol.MAX_FRAME_BYTES))
        val message = ControlMessage(messageType = MessageType.ERROR, senderNodeId = "n", sessionId = "s", payload = payload)
        assertThrows(IllegalArgumentException::class.java) { ControlProtocol.encode(message) }
    }

    @Test
    fun rejectsInvalidJson() {
        val body = "{not-json".toByteArray()
        val frame = ByteBuffer.allocate(4 + body.size).putInt(body.size).put(body).array()
        assertThrows(IllegalArgumentException::class.java) { ControlProtocol.read(ByteArrayInputStream(frame)) }
    }

    @Test
    fun writesFrameToStream() {
        val out = ByteArrayOutputStream()
        ControlProtocol.write(out, ControlMessage(messageType = MessageType.HEARTBEAT, senderNodeId = "n", sessionId = "s"))
        val decoded = ControlProtocol.read(ByteArrayInputStream(out.toByteArray()))
        assertEquals(MessageType.HEARTBEAT, decoded.messageType)
    }
}
