package com.localptt.radio.network.control

import com.localptt.radio.room.AuthRateLimiter
import com.localptt.radio.room.PeerInfo
import com.localptt.radio.room.RoomPin
import com.localptt.radio.network.audio.UdpAudioPacket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class HostControlSession(
    private val scope: CoroutineScope,
    private val roomName: String,
    private val hostNodeName: String,
    private val openRoom: Boolean,
    private val onPeers: (List<PeerInfo>) -> Unit,
    private val onSpeaker: (String?) -> Unit,
    private val onPacket: (UdpAudioPacket) -> Unit,
    private val onError: (String) -> Unit
) : AutoCloseable {
    val sessionId: String = RoomPin.newSessionId()
    val pin: String = if (openRoom) "" else RoomPin.generate()
    val controlPort: Int get() = serverSocket?.localPort ?: 0
    val audioPort: Int get() = udpSocket?.localPort ?: 0
    val sessionUuid: UUID = UUID.fromString(sessionId)

    private val limiter = AuthRateLimiter()
    private val clients = ConcurrentHashMap<String, ClientRecord>()
    private var serverSocket: ServerSocket? = null
    private var udpSocket: DatagramSocket? = null
    private var acceptJob: Job? = null
    private var udpJob: Job? = null
    private var leaseJob: Job? = null
    @Volatile private var floorOwner: String? = null
    @Volatile private var floorLeaseUntil: Long = 0

    fun start() {
        serverSocket = ServerSocket(0)
        udpSocket = DatagramSocket(0)
        acceptJob = scope.launch(Dispatchers.IO) { acceptLoop() }
        udpJob = scope.launch(Dispatchers.IO) { udpLoop() }
        leaseJob = scope.launch(Dispatchers.IO) { leaseLoop() }
        publishPeers()
    }

    suspend fun localFloorRequest(hostNodeId: String): Boolean {
        return if (tryGrant(hostNodeId)) {
            onSpeaker(hostNodeId)
            true
        } else false
    }

    fun localFloorRenew(hostNodeId: String) {
        if (floorOwner == hostNodeId) floorLeaseUntil = System.currentTimeMillis() + LEASE_MS
    }

    fun localFloorRelease(hostNodeId: String) {
        if (floorOwner == hostNodeId) {
            floorOwner = null
            floorLeaseUntil = 0
            onSpeaker(null)
            broadcast(MessageType.FLOOR_RELEASE, "host", JSONObject().put("speaker", hostNodeId))
        }
    }

    suspend fun sendFromLocal(packet: ByteArray, length: Int) {
        val socket = udpSocket ?: return
        clients.values.forEach { client ->
            val endpoint = client.udpEndpoint
            if (endpoint != null) {
                socket.send(DatagramPacket(packet, length, endpoint))
            }
        }
    }

    private suspend fun acceptLoop() {
        val server = serverSocket ?: return
        while (!server.isClosed) {
            val socket = runCatching { server.accept() }.getOrElse { break }
            scope.launch(Dispatchers.IO) { handleClient(socket) }
        }
    }

    private fun handleClient(socket: Socket) {
        val remote = socket.inetAddress.hostAddress ?: "unknown"
        var nodeId = ""
        try {
            socket.tcpNoDelay = true
            val hello = ControlProtocol.read(socket.getInputStream())
            require(hello.messageType == MessageType.HELLO) { "Expected HELLO" }
            val payload = hello.payload
            val nodeName = payload.optString("nodeName", "Android").take(ControlProtocol.MAX_NODE_NAME).ifBlank { "Android" }
            val suppliedPin = payload.optString("pin", "")
            if (!openRoom) {
                if (!limiter.canAttempt(remote) || suppliedPin != pin) {
                    limiter.recordFailure(remote)
                    ControlProtocol.write(
                        socket.getOutputStream(),
                        message(MessageType.AUTH_RESULT, "host", JSONObject().put("ok", false).put("reason", "Invalid PIN"))
                    )
                    socket.close()
                    return
                }
            }
            limiter.clear(remote)
            nodeId = hello.senderNodeId.take(64)
            val udpPort = payload.optInt("udpPort", -1)
            val endpoint = if (udpPort in 1..65535) InetSocketAddress(socket.inetAddress, udpPort) else null
            val record = ClientRecord(nodeId, nodeName, socket, endpoint, RoomPin.token())
            clients[nodeId] = record
            ControlProtocol.write(socket.getOutputStream(), message(MessageType.AUTH_RESULT, "host", JSONObject().put("ok", true)))
            ControlProtocol.write(
                socket.getOutputStream(),
                message(
                    MessageType.WELCOME,
                    "host",
                    JSONObject()
                        .put("roomName", roomName)
                        .put("hostName", hostNodeName)
                        .put("sessionId", sessionId)
                        .put("token", record.token)
                        .put("audioPort", audioPort)
                        .put("sampleRate", 48_000)
                )
            )
            broadcast(MessageType.PEER_JOINED, "host", JSONObject().put("nodeId", nodeId).put("nodeName", nodeName))
            publishPeers()
            readLoop(record)
        } catch (e: Exception) {
            if (nodeId.isBlank()) onError(e.message ?: "Client rejected")
        } finally {
            if (nodeId.isNotBlank()) removeClient(nodeId)
            runCatching { socket.close() }
        }
    }

    private fun readLoop(record: ClientRecord) {
        val socket = record.socket
        while (!socket.isClosed) {
            val msg = ControlProtocol.read(socket.getInputStream())
            when (msg.messageType) {
                MessageType.HEARTBEAT -> {
                    record.lastHeartbeat = System.currentTimeMillis()
                    write(record, MessageType.HEARTBEAT_ACK, JSONObject().put("serverTime", record.lastHeartbeat))
                }
                MessageType.FLOOR_REQUEST -> {
                    if (tryGrant(record.nodeId)) {
                        write(record, MessageType.FLOOR_GRANTED, JSONObject().put("leaseMillis", LEASE_MS))
                        broadcast(MessageType.ROOM_STATUS, "host", JSONObject().put("speaker", record.nodeId))
                        onSpeaker(record.nodeId)
                    } else {
                        write(record, MessageType.FLOOR_DENIED, JSONObject().put("reason", "busy").put("speaker", floorOwner))
                    }
                }
                MessageType.FLOOR_RENEW -> if (floorOwner == record.nodeId) {
                    floorLeaseUntil = System.currentTimeMillis() + LEASE_MS
                }
                MessageType.FLOOR_RELEASE, MessageType.CLIENT_DISCONNECT -> {
                    releaseIfOwner(record.nodeId)
                    if (msg.messageType == MessageType.CLIENT_DISCONNECT) return
                }
                else -> Unit
            }
        }
    }

    private fun tryGrant(nodeId: String): Boolean {
        val now = System.currentTimeMillis()
        val owner = floorOwner
        if (owner == null || now > floorLeaseUntil) {
            floorOwner = nodeId
            floorLeaseUntil = now + LEASE_MS
            return true
        }
        return owner == nodeId
    }

    private suspend fun udpLoop() {
        val socket = udpSocket ?: return
        val buffer = ByteArray(1500)
        while (!socket.isClosed) {
            val packet = DatagramPacket(buffer, buffer.size)
            try {
                socket.receive(packet)
            } catch (_: Exception) {
                break
            }
            val sender = clients.values.firstOrNull {
                it.udpEndpoint?.address == packet.address && it.udpEndpoint?.port == packet.port
            }
            if (sender == null || floorOwner != sender.nodeId) continue
            runCatching {
                onPacket(UdpAudioPacket.decode(packet.data.copyOf(packet.length)))
            }
            clients.values.forEach { client ->
                if (client.nodeId != sender.nodeId) {
                    client.udpEndpoint?.let { endpoint ->
                        runCatching { socket.send(DatagramPacket(packet.data.copyOf(packet.length), packet.length, endpoint)) }
                    }
                }
            }
        }
    }

    private suspend fun leaseLoop() {
        while (true) {
            delay(500)
            val now = System.currentTimeMillis()
            clients.values.filter { now - it.lastHeartbeat > HEARTBEAT_TIMEOUT_MS }.forEach { removeClient(it.nodeId) }
            val owner = floorOwner
            if (owner != null && now > floorLeaseUntil) {
                floorOwner = null
                floorLeaseUntil = 0
                onSpeaker(null)
                broadcast(MessageType.FLOOR_REVOKED, "host", JSONObject().put("speaker", owner).put("reason", "lease_timeout"))
            }
        }
    }

    private fun releaseIfOwner(nodeId: String) {
        if (floorOwner == nodeId) {
            floorOwner = null
            floorLeaseUntil = 0
            onSpeaker(null)
            broadcast(MessageType.FLOOR_RELEASE, "host", JSONObject().put("speaker", nodeId))
        }
    }

    private fun removeClient(nodeId: String) {
        val removed = clients.remove(nodeId) ?: return
        releaseIfOwner(nodeId)
        runCatching { removed.socket.close() }
        broadcast(MessageType.PEER_LEFT, "host", JSONObject().put("nodeId", nodeId))
        publishPeers()
    }

    private fun publishPeers() {
        onPeers(clients.values.map { PeerInfo(it.nodeId, it.nodeName, it.socket.inetAddress.hostAddress ?: "", it.lastHeartbeat) })
        broadcastPeerList()
    }

    private fun broadcastPeerList() {
        val peers = JSONArray()
        clients.values.forEach { peers.put(JSONObject().put("nodeId", it.nodeId).put("nodeName", it.nodeName)) }
        broadcast(MessageType.PEER_LIST, "host", JSONObject().put("peers", peers).put("speaker", floorOwner))
    }

    private fun broadcast(type: MessageType, sender: String, payload: JSONObject) {
        clients.values.forEach { write(it, type, payload) }
    }

    private fun write(record: ClientRecord, type: MessageType, payload: JSONObject) {
        runCatching { ControlProtocol.write(record.socket.getOutputStream(), message(type, "host", payload)) }
    }

    private fun message(type: MessageType, sender: String, payload: JSONObject): ControlMessage =
        ControlMessage(messageType = type, senderNodeId = sender, sessionId = sessionId, payload = payload)

    override fun close() {
        broadcast(MessageType.HOST_SHUTDOWN, "host", JSONObject())
        acceptJob?.cancel()
        udpJob?.cancel()
        leaseJob?.cancel()
        clients.values.forEach { runCatching { it.socket.close() } }
        clients.clear()
        runCatching { serverSocket?.close() }
        runCatching { udpSocket?.close() }
        floorOwner = null
    }

    private data class ClientRecord(
        val nodeId: String,
        val nodeName: String,
        val socket: Socket,
        val udpEndpoint: InetSocketAddress?,
        val token: String,
        @Volatile var lastHeartbeat: Long = System.currentTimeMillis()
    )

    companion object {
        const val LEASE_MS = 3_000L
        const val RENEW_MS = 1_000L
        const val HEARTBEAT_TIMEOUT_MS = 12_000L
    }
}
