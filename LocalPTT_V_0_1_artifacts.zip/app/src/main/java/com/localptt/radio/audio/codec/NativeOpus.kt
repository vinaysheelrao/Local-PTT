package com.localptt.radio.audio.codec

object NativeOpus {
    init {
        System.loadLibrary("localptt_opus_jni")
    }

    external fun createEncoder(sampleRate: Int, channels: Int, bitrate: Int): Long
    external fun encode(
        handle: Long,
        pcm: ShortArray,
        pcmOffset: Int,
        frameSize: Int,
        output: ByteArray,
        outputOffset: Int,
        maxBytes: Int
    ): Int
    external fun destroyEncoder(handle: Long)

    external fun createDecoder(sampleRate: Int, channels: Int): Long
    external fun decode(
        handle: Long,
        packet: ByteArray,
        packetOffset: Int,
        packetLength: Int,
        pcm: ShortArray,
        pcmOffset: Int,
        frameSize: Int,
        fec: Boolean
    ): Int
    external fun destroyDecoder(handle: Long)
}

class OpusEncoder(
    sampleRate: Int,
    private val frameSize: Int,
    bitrate: Int = 24_000
) : AutoCloseable {
    private var handle: Long = NativeOpus.createEncoder(sampleRate, 1, bitrate)

    init {
        require(handle != 0L) { "Failed to create Opus encoder" }
    }

    fun encode(pcm: ShortArray, output: ByteArray): Int {
        check(handle != 0L) { "Encoder closed" }
        return NativeOpus.encode(handle, pcm, 0, frameSize, output, 0, output.size)
    }

    override fun close() {
        val local = handle
        handle = 0
        if (local != 0L) NativeOpus.destroyEncoder(local)
    }
}

class OpusDecoder(
    sampleRate: Int,
    private val frameSize: Int
) : AutoCloseable {
    private var handle: Long = NativeOpus.createDecoder(sampleRate, 1)

    init {
        require(handle != 0L) { "Failed to create Opus decoder" }
    }

    fun decode(packet: ByteArray, packetLength: Int, pcm: ShortArray, fec: Boolean = false): Int {
        check(handle != 0L) { "Decoder closed" }
        return NativeOpus.decode(handle, packet, 0, packetLength, pcm, 0, frameSize, fec)
    }

    fun conceal(pcm: ShortArray): Int {
        check(handle != 0L) { "Decoder closed" }
        return NativeOpus.decode(handle, ByteArray(0), 0, 0, pcm, 0, frameSize, false)
    }

    override fun close() {
        val local = handle
        handle = 0
        if (local != 0L) NativeOpus.destroyDecoder(local)
    }
}
