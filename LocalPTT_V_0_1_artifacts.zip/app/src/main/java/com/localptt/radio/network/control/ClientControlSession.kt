package com.localptt.radio.network.control

import com.localptt.radio.network.audio.UdpAudioPacket
import com.localptt.radio.room.PeerInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID

class ClientControlSession(
    private val scope: CoroutineScope,
    private val nodeId: String,
    private val nodeName: String,
    private val hostAddress: InetAddress,
    private val controlPort: Int,
    private val pin: String,
    private val onConnected: (String, String, Int) -> Unit,
    private val onPeers: (List<PeerInfo>) -> Unit,
    private val onFloorGranted: () -> Unit,
    private val onFloorDenied: (String?) -> Unit,
    private val onSpeaker: (String?) -> Unit,
    private val onPacket: (UdpAudioPacket) -> Unit,
    private val onDisconnected: (String?) -> Unit
) : AutoCloseable {
    val localAudioPort: Int get() = udpSocket?.localPort ?: 0
    var sessionId: String = ""
        private set
    val sessionUuid: UUID? get() = runCatching { UUID.fromString(sessionId) }.getOrNull()

    private var socket: Socket? = null
    private var udpSocket: DatagramSocket? = null
    private var readJob: Job? = null
    private var heartbeatJob: Job? = null
    private var udpJob: Job? = null
    @Volatile private var audioPort: Int = 0

    fun start() {
        udpSocket = DatagramSocket(0)
        socket = Socket().apply {
            tcpNoDelay = true
            connect(InetSocketAddress(hostAddress, controlPort), 5_000)
        }
        val out = socket!!.getOutputStream()
        ControlProtocol.write(
            out,
            ControlMessage(
                messageType = MessageType.HELLO,
                senderNodeId = nodeId,
                sessionId = "",
                payload = JSONObject()
                    .put("nodeName", nodeName)
                    .put("pin", pin)
                    .put("udpPort", localAudioPort)
            )
        )
        val auth = ControlProtocol.read(socket!!.getInputStream())
        if (!auth.payload.optBoolean("ok", false)) {
            throw SecurityException(auth.payload.optString("reason", "Authentication failed"))
        }
        val welcome = ControlProtocol.read(socket!!.getInputStream())
        require(welcome.messageType == MessageType.WELCOME)
        sessionId = welcome.payload.getString("sessionId")
        audioPort = welcome.payload.getInt("audioPort")
        onConnected(welcome.payload.optString("roomName"), welcome.payload.optString("hostName"), audioPort)
        readJob = scope.launch(Dispatchers.IO) { readLoop() }
        heartbeatJob = scope.launch(Dispatchers.IO) { heartbeatLoop() }
        udpJob = scope.launch(Dispatchers.IO) { udpLoop() }
    }

    fun requestFloor() = send(MessageType.FLOOR_REQUEST, JSONObject())
    fun renewFloor() = send(MessageType.FLOOR_RENEW, JSONObject())
    fun releaseFloor() = send(MessageType.FLOOR_RELEASE, JSONObject())

    suspend fun sendAudio(bytes: ByteArray, length: Int) {
        val udp = udpSocket ?: return
        if (audioPort > 0) {
            udp.send(DatagramPacket(bytes, length, hostAddress, audioPort))
        }
    }

    private fun readLoop() {
        val input = socket?.getInputStream() ?: return
        try {
            while (true) {
                handle(ControlProtocol.read(input))
            }
        } catch (e: Exception) {
            onDisconnected(e.message)
        }
    }

    private fun handle(msg: ControlMessage) {
        when (msg.messageType) {
            MessageType.HEARTBEAT_ACK -> Unit
            MessageType.FLOOR_GRANTED -> onFloorGranted()
            MessageType.FLOOR_DENIED -> onFloorDenied(msg.payload.optString("speaker", null))
            MessageType.FLOOR_REVOKED, MessageType.FLOOR_RELEASE -> onSpeaker(null)
            MessageType.ROOM_STATUS -> onSpeaker(msg.payload.optString("speaker", null))
            MessageType.PEER_LIST -> {
                val peers = mutableListOf<PeerInfo>()
                val arr = msg.payload.optJSONArray("peers")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        peers += PeerInfo(item.optString("nodeId"), item.optString("nodeName"))
                    }
                }
                onPeers(peers)
                onSpeaker(msg.payload.optString("speaker", null))
            }
            MessageType.HOST_SHUTDOWN -> onDisconnected("Host closed the room")
            else -> Unit
        }
    }

    private suspend fun heartbeatLoop() {
        while (true) {
            delay(3_000)
            send(MessageType.HEARTBEAT, JSONObject().put("time", System.currentTimeMillis()))
        }
    }

    private suspend fun udpLoop() {
        val udp = udpSocket ?: return
        val buffer = ByteArray(1500)
        while (!udp.isClosed) {
            val datagram = DatagramPacket(buffer, buffer.size)
            try {
                udp.receive(datagram)
            } catch (_: Exception) {
                break
            }
            runCatching {
                val packet = UdpAudioPacket.decode(datagram.data.copyOf(datagram.length))
                onPacket(packet)
            }
        }
    }

    private fun send(type: MessageType, payload: JSONObject) {
        val out = socket?.getOutputStream() ?: return
        runCatching {
            ControlProtocol.write(out, ControlMessage(messageType = type, senderNodeId = nodeId, sessionId = sessionId, payload = payload))
        }
    }

    override fun close() {
        send(MessageType.CLIENT_DISCONNECT, JSONObject())
        readJob?.cancel()
        heartbeatJob?.cancel()
        udpJob?.cancel()
        runCatching { socket?.close() }
        runCatching { udpSocket?.close() }
    }
}
