package com.localptt.radio.room

import com.localptt.radio.diagnostics.DiagnosticsSnapshot
import com.localptt.radio.floor.RadioState
import java.net.InetAddress

enum class RadioRole { NONE, HOST, CLIENT }

data class PeerInfo(
    val nodeId: String,
    val nodeName: String,
    val address: String = "",
    val lastHeartbeat: Long = System.currentTimeMillis()
)

data class DiscoveredRoom(
    val serviceName: String,
    val roomName: String,
    val hostName: String,
    val hostAddress: InetAddress?,
    val controlPort: Int,
    val protocolVersion: Int,
    val pinRequired: Boolean,
    val lastSeen: Long = System.currentTimeMillis()
)

data class RoomStatus(
    val role: RadioRole = RadioRole.NONE,
    val state: RadioState = RadioState.DISCONNECTED,
    val roomName: String = "",
    val hostName: String = "",
    val localNodeId: String = "",
    val sessionId: String = "",
    val pin: String = "",
    val localIp: String = "",
    val controlPort: Int = 0,
    val audioPort: Int = 0,
    val currentSpeaker: String? = null,
    val peers: List<PeerInfo> = emptyList(),
    val discoveredRooms: List<DiscoveredRoom> = emptyList(),
    val error: String? = null,
    val diagnostics: DiagnosticsSnapshot = DiagnosticsSnapshot()
)
