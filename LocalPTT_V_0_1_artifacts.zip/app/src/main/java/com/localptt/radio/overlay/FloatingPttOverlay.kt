package com.localptt.radio.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import com.localptt.radio.floor.RadioState
import com.localptt.radio.permissions.PermissionHelper
import kotlin.math.abs

class FloatingPttOverlay(
    private val context: Context,
    private val onDown: () -> Unit,
    private val onUp: () -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f
    private var dragging = false
    private var pttStarted = false
    private val threshold = ViewConfiguration.get(context).scaledTouchSlop

    fun show(sizeDp: Int) {
        if (!PermissionHelper.canDrawOverlay(context) || view != null) return
        val density = context.resources.displayMetrics.density
        val size = (sizeDp * density).toInt()
        val button = TextView(context).apply {
            text = "PTT"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xCC22577A.toInt())
            setOnTouchListener { _, event -> handleTouch(event) }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            size,
            size,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = (160 * density).toInt()
        }
        params = lp
        view = button
        windowManager.addView(button, lp)
    }

    fun update(state: RadioState) {
        view?.text = when (state) {
            RadioState.REQUESTING_FLOOR -> "..."
            RadioState.TRANSMITTING -> "TALK"
            RadioState.BUSY, RadioState.RECEIVING -> "BUSY"
            RadioState.DISCONNECTED, RadioState.ERROR -> "OFF"
            else -> "PTT"
        }
        view?.setBackgroundColor(
            when (state) {
                RadioState.TRANSMITTING -> 0xCC2D9C74.toInt()
                RadioState.REQUESTING_FLOOR -> 0xCCB7791F.toInt()
                RadioState.BUSY, RadioState.RECEIVING -> 0xCCB42318.toInt()
                RadioState.DISCONNECTED, RadioState.ERROR -> 0xCC607080.toInt()
                else -> 0xCC22577A.toInt()
            }
        )
    }

    fun remove() {
        if (pttStarted) onUp()
        pttStarted = false
        val local = view ?: return
        runCatching { windowManager.removeView(local) }
        view = null
        params = null
    }

    private fun handleTouch(event: MotionEvent): Boolean {
        val lp = params ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = lp.x
                startY = lp.y
                touchX = event.rawX
                touchY = event.rawY
                dragging = false
                pttStarted = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - touchX
                val dy = event.rawY - touchY
                if (!dragging && (abs(dx) > threshold || abs(dy) > threshold)) dragging = true
                if (dragging) {
                    lp.x = startX + dx.toInt()
                    lp.y = (startY + dy.toInt()).coerceAtLeast(0)
                    windowManager.updateViewLayout(view, lp)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) {
                    if (!pttStarted) onDown()
                    onUp()
                } else {
                    snap(lp)
                }
                pttStarted = false
                dragging = false
                return true
            }
        }
        if (!dragging && event.eventTime - event.downTime > 120 && !pttStarted) {
            pttStarted = true
            onDown()
            view?.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
        }
        return true
    }

    private fun snap(lp: WindowManager.LayoutParams) {
        val width = context.resources.displayMetrics.widthPixels
        lp.x = if (lp.x + lp.width / 2 < width / 2) 0 else width - lp.width
        windowManager.updateViewLayout(view, lp)
    }
}
