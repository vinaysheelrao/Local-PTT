package com.localptt.radio.room

import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.min

object RoomPin {
    private val random = SecureRandom()

    fun generate(): String = random.nextInt(900_000).plus(100_000).toString()

    fun newSessionId(): String = UUID.randomUUID().toString()

    fun token(): String = UUID.randomUUID().toString() + "-" + random.nextLong().toString(16)
}

class AuthRateLimiter(
    private val maxAttempts: Int = 5,
    private val windowMillis: Long = 60_000L
) {
    private data class Attempts(var count: Int, var firstAt: Long)
    private val attempts = ConcurrentHashMap<String, Attempts>()

    fun recordFailure(address: String, now: Long = System.currentTimeMillis()): Boolean {
        val item = attempts.compute(address) { _, existing ->
            if (existing == null || now - existing.firstAt > windowMillis) Attempts(1, now)
            else existing.apply { count = min(count + 1, maxAttempts + 1) }
        } ?: Attempts(1, now)
        return item.count <= maxAttempts
    }

    fun canAttempt(address: String, now: Long = System.currentTimeMillis()): Boolean {
        val item = attempts[address] ?: return true
        if (now - item.firstAt > windowMillis) {
            attempts.remove(address)
            return true
        }
        return item.count < maxAttempts
    }

    fun clear(address: String) {
        attempts.remove(address)
    }
}
