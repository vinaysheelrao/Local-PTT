package com.localptt.radio.app

import android.app.Application

class LocalPttApplication : Application()
