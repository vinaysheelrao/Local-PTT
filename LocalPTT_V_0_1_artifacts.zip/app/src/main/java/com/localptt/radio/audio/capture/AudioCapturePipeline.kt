package com.localptt.radio.audio.capture

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Process
import com.localptt.radio.audio.codec.OpusEncoder
import com.localptt.radio.audio.effects.PlatformAudioEffects
import com.localptt.radio.network.audio.AudioConstants
import com.localptt.radio.network.audio.UdpAudioPacket
import com.localptt.radio.settings.RadioSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

class AudioCapturePipeline(
    private val context: Context,
    private val scope: CoroutineScope,
    private val settingsProvider: () -> RadioSettings,
    private val packetSender: suspend (UdpAudioPacket) -> Unit,
    private val onStopped: (String?) -> Unit
) {
    private var job: Job? = null
    private val running = AtomicBoolean(false)

    val isRunning: Boolean get() = running.get()

    fun start(sessionId: UUID, nodeNumericId: Long, streamId: Int, sampleRate: Int = 48_000) {
        if (running.getAndSet(true)) return
        job = scope.launch {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            var record: AudioRecord? = null
            var effects: PlatformAudioEffects? = null
            var encoder: OpusEncoder? = null
            try {
                if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    throw SecurityException("Microphone permission denied")
                }
                val actualRate = if (canInitialize(sampleRate)) sampleRate else 16_000
                val frameSize = actualRate / 50
                val minBuffer = AudioRecord.getMinBufferSize(
                    actualRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                val recordBuffer = maxOf(minBuffer, frameSize * 4 * 2)
                record = AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(actualRate)
                            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .build()
                    )
                    .setBufferSizeInBytes(recordBuffer)
                    .build()
                val settings = settingsProvider()
                effects = PlatformAudioEffects(
                    record.audioSessionId,
                    settings.noiseSuppression,
                    settings.echoCancellation,
                    settings.automaticGain
                ).also { it.attach() }
                encoder = OpusEncoder(actualRate, frameSize)
                val pcm = ShortArray(frameSize)
                val opus = ByteArray(AudioConstants.MAX_PAYLOAD_BYTES)
                var sequence = 0L
                val sampleRateId = if (actualRate == 48_000) AudioConstants.SAMPLE_48K else AudioConstants.SAMPLE_16K
                record.startRecording()
                packetSender(
                    UdpAudioPacket(
                        flags = AudioConstants.FLAG_STREAM_START,
                        sessionId = sessionId,
                        senderNodeId = nodeNumericId,
                        streamId = streamId,
                        sequence = sequence++,
                        audioTimestamp = System.nanoTime(),
                        sampleRateId = sampleRateId,
                        payload = ByteArray(0)
                    )
                )
                while (running.get()) {
                    val read = record.read(pcm, 0, pcm.size, AudioRecord.READ_BLOCKING)
                    if (read <= 0) continue
                    if (read < pcm.size) pcm.fill(0, read, pcm.size)
                    val encoded = encoder.encode(pcm, opus)
                    if (encoded > 0) {
                        packetSender(
                            UdpAudioPacket(
                                flags = AudioConstants.FLAG_AUDIO_FRAME or AudioConstants.FLAG_FEC_AVAILABLE,
                                sessionId = sessionId,
                                senderNodeId = nodeNumericId,
                                streamId = streamId,
                                sequence = sequence++,
                                audioTimestamp = System.nanoTime(),
                                sampleRateId = sampleRateId,
                                payload = opus.copyOf(encoded)
                            )
                        )
                    }
                }
                withContext(NonCancellable) {
                    packetSender(
                        UdpAudioPacket(
                            flags = AudioConstants.FLAG_STREAM_END,
                            sessionId = sessionId,
                            senderNodeId = nodeNumericId,
                            streamId = streamId,
                            sequence = sequence,
                            audioTimestamp = System.nanoTime(),
                            sampleRateId = sampleRateId,
                            payload = ByteArray(0)
                        )
                    )
                }
                onStopped(null)
            } catch (e: Exception) {
                onStopped(e.message ?: e.javaClass.simpleName)
            } finally {
                running.set(false)
                runCatching { record?.stop() }
                runCatching { record?.release() }
                runCatching { effects?.close() }
                runCatching { encoder?.close() }
            }
        }
    }

    fun stop() {
        running.set(false)
        job?.cancel()
        job = null
    }

    private fun canInitialize(sampleRate: Int): Boolean {
        val min = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        return min > 0
    }
}
