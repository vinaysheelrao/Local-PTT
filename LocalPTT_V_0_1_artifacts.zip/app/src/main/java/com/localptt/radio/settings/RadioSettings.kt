package com.localptt.radio.settings

import android.content.Context
import android.os.Build

data class RadioSettings(
    val nodeName: String,
    val noiseSuppression: Boolean = true,
    val echoCancellation: Boolean = true,
    val automaticGain: Boolean = true,
    val haptics: Boolean = true,
    val overlaySizeDp: Int = 96,
    val diagnosticLogging: Boolean = false
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("localptt_settings", Context.MODE_PRIVATE)

    fun load(): RadioSettings = RadioSettings(
        nodeName = prefs.getString("nodeName", defaultNodeName()) ?: defaultNodeName(),
        noiseSuppression = prefs.getBoolean("noiseSuppression", true),
        echoCancellation = prefs.getBoolean("echoCancellation", true),
        automaticGain = prefs.getBoolean("automaticGain", true),
        haptics = prefs.getBoolean("haptics", true),
        overlaySizeDp = prefs.getInt("overlaySizeDp", 96),
        diagnosticLogging = prefs.getBoolean("diagnosticLogging", false)
    )

    fun save(settings: RadioSettings) {
        prefs.edit()
            .putString("nodeName", settings.nodeName.take(32).ifBlank { defaultNodeName() })
            .putBoolean("noiseSuppression", settings.noiseSuppression)
            .putBoolean("echoCancellation", settings.echoCancellation)
            .putBoolean("automaticGain", settings.automaticGain)
            .putBoolean("haptics", settings.haptics)
            .putInt("overlaySizeDp", settings.overlaySizeDp.coerceIn(72, 132))
            .putBoolean("diagnosticLogging", settings.diagnosticLogging)
            .apply()
    }

    private fun defaultNodeName(): String = "Android-${Build.MODEL}".take(32)
}
