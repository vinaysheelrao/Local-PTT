package com.localptt.radio.floor

enum class RadioState {
    DISCONNECTED,
    DISCOVERING,
    CONNECTING,
    CONNECTED_IDLE,
    REQUESTING_FLOOR,
    TRANSMITTING,
    RECEIVING,
    BUSY,
    RECONNECTING,
    ERROR
}
