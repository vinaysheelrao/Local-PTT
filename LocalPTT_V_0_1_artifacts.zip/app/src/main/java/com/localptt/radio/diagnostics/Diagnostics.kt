package com.localptt.radio.diagnostics

import java.util.concurrent.atomic.AtomicLong

data class DiagnosticsSnapshot(
    val packetsSent: Long = 0,
    val packetsReceived: Long = 0,
    val packetsDropped: Long = 0,
    val lastHeartbeat: Long = 0,
    val jitterDepth: Int = 0,
    val reconnectCount: Long = 0,
    val selectedSampleRate: Int = 48_000,
    val opusBitrate: Int = 24_000
)

class DiagnosticsCounters {
    private val sent = AtomicLong()
    private val received = AtomicLong()
    private val dropped = AtomicLong()
    private val reconnects = AtomicLong()
    @Volatile private var lastHeartbeat = 0L
    @Volatile private var jitterDepth = 0
    @Volatile private var selectedSampleRate = 48_000

    fun sent() = sent.incrementAndGet()
    fun received() = received.incrementAndGet()
    fun dropped() = dropped.incrementAndGet()
    fun heartbeat(time: Long = System.currentTimeMillis()) { lastHeartbeat = time }
    fun jitterDepth(value: Int) { jitterDepth = value }
    fun reconnect() = reconnects.incrementAndGet()
    fun sampleRate(value: Int) { selectedSampleRate = value }

    fun snapshot(): DiagnosticsSnapshot = DiagnosticsSnapshot(
        packetsSent = sent.get(),
        packetsReceived = received.get(),
        packetsDropped = dropped.get(),
        lastHeartbeat = lastHeartbeat,
        jitterDepth = jitterDepth,
        reconnectCount = reconnects.get(),
        selectedSampleRate = selectedSampleRate
    )
}
