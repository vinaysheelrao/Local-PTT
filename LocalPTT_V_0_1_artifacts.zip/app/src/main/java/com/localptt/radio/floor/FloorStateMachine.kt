package com.localptt.radio.floor

class FloorStateMachine {
    var state: RadioState = RadioState.DISCONNECTED
        private set
    var pttHeld: Boolean = false
        private set
    var currentSpeaker: String? = null
        private set

    fun disconnected() {
        pttHeld = false
        currentSpeaker = null
        state = RadioState.DISCONNECTED
    }

    fun discovering() {
        require(state == RadioState.DISCONNECTED || state == RadioState.ERROR)
        state = RadioState.DISCOVERING
    }

    fun connecting() {
        require(state == RadioState.DISCONNECTED || state == RadioState.DISCOVERING || state == RadioState.RECONNECTING)
        state = RadioState.CONNECTING
    }

    fun connected() {
        currentSpeaker = null
        state = RadioState.CONNECTED_IDLE
    }

    fun pressPtt(): FloorAction {
        if (state != RadioState.CONNECTED_IDLE && state != RadioState.BUSY && state != RadioState.RECEIVING) {
            return FloorAction.IGNORE
        }
        pttHeld = true
        currentSpeaker = null
        state = RadioState.REQUESTING_FLOOR
        return FloorAction.REQUEST_FLOOR
    }

    fun grant(localNodeId: String): FloorAction {
        return if (state == RadioState.REQUESTING_FLOOR && pttHeld) {
            currentSpeaker = localNodeId
            state = RadioState.TRANSMITTING
            FloorAction.START_CAPTURE
        } else {
            state = RadioState.CONNECTED_IDLE
            FloorAction.RELEASE_FLOOR
        }
    }

    fun deny(remoteSpeaker: String?): FloorAction {
        currentSpeaker = remoteSpeaker
        state = RadioState.BUSY
        return FloorAction.STOP_CAPTURE
    }

    fun remoteSpeakerStarted(nodeId: String) {
        if (!pttHeld) {
            currentSpeaker = nodeId
            state = RadioState.RECEIVING
        }
    }

    fun releasePtt(): FloorAction {
        pttHeld = false
        val action = if (state == RadioState.TRANSMITTING || state == RadioState.REQUESTING_FLOOR) {
            FloorAction.STOP_AND_RELEASE
        } else {
            FloorAction.STOP_CAPTURE
        }
        currentSpeaker = null
        state = RadioState.CONNECTED_IDLE
        return action
    }

    fun remoteSpeakerEnded() {
        if (state == RadioState.RECEIVING || state == RadioState.BUSY) {
            currentSpeaker = null
            state = RadioState.CONNECTED_IDLE
        }
    }

    fun error() {
        pttHeld = false
        currentSpeaker = null
        state = RadioState.ERROR
    }
}

enum class FloorAction {
    IGNORE,
    REQUEST_FLOOR,
    START_CAPTURE,
    STOP_CAPTURE,
    STOP_AND_RELEASE,
    RELEASE_FLOOR
}
