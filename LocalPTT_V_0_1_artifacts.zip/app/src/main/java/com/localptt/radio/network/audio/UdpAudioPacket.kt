package com.localptt.radio.network.audio

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID

data class UdpAudioPacket(
    val flags: Int,
    val sessionId: UUID,
    val senderNodeId: Long,
    val streamId: Int,
    val sequence: Long,
    val audioTimestamp: Long,
    val codec: Int = AudioConstants.CODEC_OPUS,
    val sampleRateId: Int = AudioConstants.SAMPLE_48K,
    val payload: ByteArray
) {
    fun encode(): ByteArray {
        require(payload.size <= AudioConstants.MAX_PAYLOAD_BYTES) { "Opus payload too large" }
        val buffer = ByteBuffer.allocate(AudioConstants.HEADER_BYTES + payload.size)
            .order(ByteOrder.BIG_ENDIAN)
        buffer.putInt(AudioConstants.MAGIC)
        buffer.put(AudioConstants.VERSION.toByte())
        buffer.put(flags.toByte())
        buffer.putLong(sessionId.mostSignificantBits)
        buffer.putLong(sessionId.leastSignificantBits)
        buffer.putLong(senderNodeId)
        buffer.putInt(streamId)
        buffer.putInt((sequence and 0xFFFF_FFFFL).toInt())
        buffer.putLong(audioTimestamp)
        buffer.put(codec.toByte())
        buffer.put(sampleRateId.toByte())
        buffer.putShort(payload.size.toShort())
        buffer.put(payload)
        return buffer.array()
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is UdpAudioPacket) return false
        return flags == other.flags &&
            sessionId == other.sessionId &&
            senderNodeId == other.senderNodeId &&
            streamId == other.streamId &&
            sequence == other.sequence &&
            audioTimestamp == other.audioTimestamp &&
            codec == other.codec &&
            sampleRateId == other.sampleRateId &&
            payload.contentEquals(other.payload)
    }

    override fun hashCode(): Int {
        var result = flags
        result = 31 * result + sessionId.hashCode()
        result = 31 * result + senderNodeId.hashCode()
        result = 31 * result + streamId
        result = 31 * result + sequence.hashCode()
        result = 31 * result + audioTimestamp.hashCode()
        result = 31 * result + codec
        result = 31 * result + sampleRateId
        result = 31 * result + payload.contentHashCode()
        return result
    }

    companion object {
        fun decode(bytes: ByteArray, length: Int = bytes.size): UdpAudioPacket {
            require(length in AudioConstants.HEADER_BYTES..AudioConstants.MAX_PACKET_BYTES) { "Invalid UDP packet size" }
            val buffer = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.BIG_ENDIAN)
            require(buffer.int == AudioConstants.MAGIC) { "Bad audio packet magic" }
            require(buffer.get().toInt() and 0xFF == AudioConstants.VERSION) { "Bad audio packet version" }
            val flags = buffer.get().toInt() and 0xFF
            val session = UUID(buffer.long, buffer.long)
            val sender = buffer.long
            val stream = buffer.int
            val sequence = buffer.int.toLong() and 0xFFFF_FFFFL
            val timestamp = buffer.long
            val codec = buffer.get().toInt() and 0xFF
            val sampleRateId = buffer.get().toInt() and 0xFF
            val payloadLength = buffer.short.toInt() and 0xFFFF
            require(payloadLength <= AudioConstants.MAX_PAYLOAD_BYTES) { "Audio payload too large" }
            require(AudioConstants.HEADER_BYTES + payloadLength == length) { "Audio payload length mismatch" }
            require(codec == AudioConstants.CODEC_OPUS) { "Unsupported codec" }
            require(sampleRateId == AudioConstants.SAMPLE_48K || sampleRateId == AudioConstants.SAMPLE_16K) {
                "Unsupported sample rate"
            }
            val payload = ByteArray(payloadLength)
            buffer.get(payload)
            return UdpAudioPacket(flags, session, sender, stream, sequence, timestamp, codec, sampleRateId, payload)
        }
    }
}
