package com.localptt.radio.network.audio

object AudioConstants {
    const val MAGIC = 0x4C505454
    const val VERSION = 1
    const val CODEC_OPUS = 1
    const val SAMPLE_48K = 48
    const val SAMPLE_16K = 16
    const val FLAG_STREAM_START = 1
    const val FLAG_AUDIO_FRAME = 1 shl 1
    const val FLAG_STREAM_END = 1 shl 2
    const val FLAG_FEC_AVAILABLE = 1 shl 3
    const val MAX_PAYLOAD_BYTES = 1275
    const val MAX_PACKET_BYTES = 1500
    const val HEADER_BYTES = 50
}
