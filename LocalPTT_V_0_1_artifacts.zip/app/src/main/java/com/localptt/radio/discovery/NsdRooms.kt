package com.localptt.radio.discovery

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import com.localptt.radio.network.control.ControlProtocol
import com.localptt.radio.room.DiscoveredRoom
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap

class NsdRoomAdvertiser(private val context: Context) {
    private val nsdManager = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var listener: NsdManager.RegistrationListener? = null

    fun start(roomName: String, hostName: String, controlPort: Int, pinRequired: Boolean, onError: (String) -> Unit) {
        stop()
        val serviceInfo = NsdServiceInfo().apply {
            serviceName = roomName.ifBlank { "LocalPTT" }
            serviceType = SERVICE_TYPE
            port = controlPort
            setAttribute("protocol", ControlProtocol.PROTOCOL_VERSION.toString())
            setAttribute("room", roomName.take(40))
            setAttribute("host", hostName.take(32))
            setAttribute("pin", if (pinRequired) "1" else "0")
            setAttribute("audio", "1")
        }
        listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) = Unit
            override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                onError("NSD registration failed: $errorCode")
            }
            override fun onServiceUnregistered(info: NsdServiceInfo) = Unit
            override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                onError("NSD unregistration failed: $errorCode")
            }
        }
        nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    fun stop() {
        val existing = listener ?: return
        runCatching { nsdManager.unregisterService(existing) }
        listener = null
    }

    companion object {
        const val SERVICE_TYPE = "_localptt._tcp."
    }
}

class NsdRoomDiscovery(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onRooms: (List<DiscoveredRoom>) -> Unit,
    private val onError: (String) -> Unit
) {
    private val nsdManager = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val rooms = ConcurrentHashMap<String, DiscoveredRoom>()
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    fun start() {
        stop()
        multicastLock = wifiManager.createMulticastLock("LocalPTT-nsd").apply {
            setReferenceCounted(false)
            runCatching { acquire() }
        }
        val listener = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                onError("NSD discovery start failed: $errorCode")
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                onError("NSD discovery stop failed: $errorCode")
            }

            override fun onDiscoveryStarted(serviceType: String) = Unit
            override fun onDiscoveryStopped(serviceType: String) = Unit
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                rooms.remove(serviceInfo.serviceName)
                publish()
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                if (serviceInfo.serviceType != NsdRoomAdvertiser.SERVICE_TYPE) return
                scope.launch(Dispatchers.IO) {
                    runCatching {
                        nsdManager.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                                onError("NSD resolve failed: $errorCode")
                            }

                            override fun onServiceResolved(info: NsdServiceInfo) {
                                val attrs = info.attributes
                                val room = attrs["room"]?.toStringUtf8() ?: info.serviceName
                                val host = attrs["host"]?.toStringUtf8() ?: "Host"
                                val protocol = attrs["protocol"]?.toStringUtf8()?.toIntOrNull() ?: 1
                                val pin = attrs["pin"]?.toStringUtf8() != "0"
                                rooms[info.serviceName] = DiscoveredRoom(
                                    serviceName = info.serviceName,
                                    roomName = room,
                                    hostName = host,
                                    hostAddress = info.host,
                                    controlPort = info.port,
                                    protocolVersion = protocol,
                                    pinRequired = pin
                                )
                                publish()
                            }
                        })
                    }.onFailure {
                        onError(it.message ?: "NSD resolve failed")
                    }
                }
            }
        }
        discoveryListener = listener
        nsdManager.discoverServices(NsdRoomAdvertiser.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    fun stop() {
        val listener = discoveryListener
        if (listener != null) runCatching { nsdManager.stopServiceDiscovery(listener) }
        discoveryListener = null
        runCatching { multicastLock?.release() }
        multicastLock = null
    }

    private fun publish() {
        onRooms(rooms.values.sortedBy { it.roomName })
    }

    private fun ByteArray.toStringUtf8(): String = String(this, StandardCharsets.UTF_8)
}
