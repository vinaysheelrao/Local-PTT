package com.localptt.radio.audio.playback

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Process
import com.localptt.radio.audio.codec.OpusDecoder
import com.localptt.radio.audio.jitter.JitterBuffer
import com.localptt.radio.audio.jitter.PollResult
import com.localptt.radio.network.audio.AudioConstants
import com.localptt.radio.network.audio.UdpAudioPacket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

class AudioPlaybackPipeline(private val scope: CoroutineScope) : AutoCloseable {
    private val channel = Channel<UdpAudioPacket>(
        capacity = 48,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    private var job: Job? = null
    private var track: AudioTrack? = null
    private var decoder: OpusDecoder? = null
    private val muted = AtomicBoolean(false)
    @Volatile var jitterDepth: Int = 0
        private set

    fun start(sampleRate: Int = 48_000) {
        if (job != null) return
        val frameSize = sampleRate / 50
        decoder = OpusDecoder(sampleRate, frameSize)
        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuffer, frameSize * 8 * 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track?.play()
        job = scope.launch {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val jitter = JitterBuffer(8)
            val pcm = ShortArray(frameSize)
            for (packet in channel) {
                if (packet.flags and AudioConstants.FLAG_STREAM_START != 0) {
                    jitter.reset(packet.streamId)
                    continue
                }
                if (packet.flags and AudioConstants.FLAG_STREAM_END != 0) {
                    jitter.reset()
                    track?.flush()
                    continue
                }
                if (packet.flags and AudioConstants.FLAG_AUDIO_FRAME == 0) continue
                jitter.offer(packet)
                jitterDepth = jitter.depth()
                drain(jitter, pcm)
            }
        }
    }

    fun play(packet: UdpAudioPacket) {
        if (!muted.get()) channel.trySend(packet)
    }

    fun setMuted(value: Boolean) {
        muted.set(value)
        if (value) runCatching { track?.pause(); track?.flush() }
        else runCatching { track?.play() }
    }

    private fun drain(jitter: JitterBuffer, pcm: ShortArray) {
        while (true) {
            when (val result = jitter.poll()) {
                PollResult.Empty -> return
                PollResult.Missing -> {
                    val samples = decoder?.conceal(pcm) ?: 0
                    if (samples > 0 && !muted.get()) track?.write(pcm, 0, samples, AudioTrack.WRITE_BLOCKING)
                }
                is PollResult.Packet -> {
                    val packet = result.packet
                    val samples = decoder?.decode(packet.payload, packet.payload.size, pcm, false) ?: 0
                    if (samples > 0 && !muted.get()) track?.write(pcm, 0, samples, AudioTrack.WRITE_BLOCKING)
                }
            }
        }
    }

    override fun close() {
        channel.close()
        job?.cancel()
        job = null
        runCatching { track?.stop() }
        runCatching { track?.release() }
        runCatching { decoder?.close() }
        track = null
        decoder = null
    }
}
