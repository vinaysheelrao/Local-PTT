package com.localptt.radio.audio.jitter

import com.localptt.radio.network.audio.UdpAudioPacket
import java.util.TreeMap

class JitterBuffer(private val capacity: Int = 8) {
    private var streamId: Int? = null
    private var expected: Long? = null
    private val packets = TreeMap<Long, UdpAudioPacket>()

    fun offer(packet: UdpAudioPacket): OfferResult {
        if (streamId != packet.streamId) {
            reset(packet.streamId)
            expected = packet.sequence
        }
        if (packets.containsKey(packet.sequence)) return OfferResult.DUPLICATE
        if (packets.size >= capacity) {
            packets.pollFirstEntry()
        }
        packets[packet.sequence] = packet
        return OfferResult.ACCEPTED
    }

    fun poll(): PollResult {
        val next = expected ?: return PollResult.Empty
        val packet = packets.remove(next)
        return if (packet != null) {
            expected = (next + 1) and 0xFFFF_FFFFL
            PollResult.Packet(packet)
        } else if (packets.isNotEmpty()) {
            expected = (next + 1) and 0xFFFF_FFFFL
            PollResult.Missing
        } else {
            PollResult.Empty
        }
    }

    fun depth(): Int = packets.size

    fun reset(newStreamId: Int? = null) {
        streamId = newStreamId
        expected = null
        packets.clear()
    }
}

enum class OfferResult { ACCEPTED, DUPLICATE }

sealed class PollResult {
    data class Packet(val packet: UdpAudioPacket) : PollResult()
    data object Missing : PollResult()
    data object Empty : PollResult()
}
