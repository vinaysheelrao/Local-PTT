package com.localptt.radio.network.control

class ReconnectionBackoff(
    private val stepsMillis: LongArray = longArrayOf(500, 1000, 2000, 4000, 8000)
) {
    private var index = 0

    fun nextDelayMillis(): Long {
        val delay = stepsMillis[index]
        if (index < stepsMillis.lastIndex) index += 1
        return delay
    }

    fun reset() {
        index = 0
    }
}
