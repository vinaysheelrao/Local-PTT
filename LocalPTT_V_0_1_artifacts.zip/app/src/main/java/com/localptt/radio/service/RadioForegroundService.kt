package com.localptt.radio.service

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.os.PowerManager
import com.localptt.radio.audio.capture.AudioCapturePipeline
import com.localptt.radio.audio.playback.AudioPlaybackPipeline
import com.localptt.radio.diagnostics.DiagnosticsCounters
import com.localptt.radio.discovery.NsdRoomAdvertiser
import com.localptt.radio.discovery.NsdRoomDiscovery
import com.localptt.radio.floor.FloorAction
import com.localptt.radio.floor.FloorStateMachine
import com.localptt.radio.floor.RadioState
import com.localptt.radio.network.audio.UdpAudioPacket
import com.localptt.radio.network.control.ClientControlSession
import com.localptt.radio.network.control.HostControlSession
import com.localptt.radio.notification.RadioNotificationFactory
import com.localptt.radio.overlay.FloatingPttOverlay
import com.localptt.radio.room.DiscoveredRoom
import com.localptt.radio.room.PeerInfo
import com.localptt.radio.room.RadioRole
import com.localptt.radio.room.RoomStatus
import com.localptt.radio.settings.RadioSettings
import com.localptt.radio.settings.SettingsStore
import com.localptt.radio.util.NetworkUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.net.InetAddress
import java.util.UUID
import java.util.concurrent.CopyOnWriteArraySet

class RadioForegroundService : Service() {
    inner class LocalBinder : Binder() {
        fun service(): RadioForegroundService = this@RadioForegroundService
    }

    interface Listener {
        fun onStatus(status: RoomStatus)
    }

    private val binder = LocalBinder()
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val listeners = CopyOnWriteArraySet<Listener>()
    private lateinit var notifications: RadioNotificationFactory
    private lateinit var settingsStore: SettingsStore
    private lateinit var audioCapture: AudioCapturePipeline
    private lateinit var playback: AudioPlaybackPipeline
    private lateinit var advertiser: NsdRoomAdvertiser
    private var discovery: NsdRoomDiscovery? = null
    private var hostSession: HostControlSession? = null
    private var clientSession: ClientControlSession? = null
    private var overlay: FloatingPttOverlay? = null
    private val floor = FloorStateMachine()
    private val counters = DiagnosticsCounters()
    private var status = RoomStatus()
    private var wakeLock: PowerManager.WakeLock? = null
    private var renewJob: Job? = null
    private var streamCounter = 1
    private var nodeId = UUID.randomUUID().toString()
    private var settings = RadioSettings("Android")

    override fun onCreate() {
        super.onCreate()
        notifications = RadioNotificationFactory(this)
        settingsStore = SettingsStore(this)
        settings = settingsStore.load()
        advertiser = NsdRoomAdvertiser(this)
        playback = AudioPlaybackPipeline(ioScope)
        audioCapture = AudioCapturePipeline(
            context = this,
            scope = ioScope,
            settingsProvider = { settings },
            packetSender = { packet -> sendAudioPacket(packet) },
            onStopped = { error -> if (error != null) fail(error) }
        )
        overlay = FloatingPttOverlay(this, onDown = { pttDown() }, onUp = { pttUp() })
        notifications.ensureChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopRadio()
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(RadioNotificationFactory.NOTIFICATION_ID, notifications.build(status))
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    fun addListener(listener: Listener) {
        listeners += listener
        listener.onStatus(status)
    }

    fun removeListener(listener: Listener) {
        listeners -= listener
    }

    fun saveSettings(newSettings: RadioSettings) {
        settings = newSettings
        settingsStore.save(newSettings)
        nodeId = UUID.nameUUIDFromBytes(newSettings.nodeName.toByteArray()).toString()
        update()
    }

    fun startDiscovery() {
        floor.disconnected()
        floor.discovering()
        discovery?.stop()
        discovery = NsdRoomDiscovery(
            context = this,
            scope = ioScope,
            onRooms = { rooms -> update { copy(discoveredRooms = rooms, state = floor.state) } },
            onError = { fail(it) }
        ).also { it.start() }
        update { copy(role = RadioRole.NONE, state = RadioState.DISCOVERING, discoveredRooms = emptyList()) }
    }

    fun createRoom(roomName: String, hostName: String, openRoom: Boolean) {
        serviceScope.launch {
            stopRadio(keepForeground = true)
            settings = settings.copy(nodeName = hostName.ifBlank { settings.nodeName })
            saveSettings(settings)
            acquireWakeLock()
            playback.start(48_000)
            val session = HostControlSession(
                scope = ioScope,
                roomName = roomName.ifBlank { "LocalPTT" },
                hostNodeName = settings.nodeName,
                openRoom = openRoom,
                onPeers = { peers -> update { copy(peers = peers) } },
                onSpeaker = { speaker -> onSpeakerChanged(speaker) },
                onPacket = { packet -> receiveAudio(packet) },
                onError = { fail(it) }
            )
            hostSession = session
            session.start()
            advertiser.start(roomName, settings.nodeName, session.controlPort, !openRoom) { fail(it) }
            floor.connected()
            update {
                copy(
                    role = RadioRole.HOST,
                    state = RadioState.CONNECTED_IDLE,
                    roomName = roomName.ifBlank { "LocalPTT" },
                    hostName = settings.nodeName,
                    localNodeId = nodeId,
                    sessionId = session.sessionId,
                    pin = session.pin,
                    localIp = NetworkUtil.localIpv4(),
                    controlPort = session.controlPort,
                    audioPort = session.audioPort,
                    peers = emptyList(),
                    error = null
                )
            }
        }
    }

    fun joinRoom(room: DiscoveredRoom?, manualHost: String, manualPort: Int, pin: String) {
        serviceScope.launch {
            stopRadio(keepForeground = true)
            val address = room?.hostAddress ?: runCatching { InetAddress.getByName(manualHost) }.getOrNull()
            if (address == null) {
                fail("Enter a reachable host IP address.")
                return@launch
            }
            val port = room?.controlPort ?: manualPort
            if (port !in 1..65535) {
                fail("Enter a valid control port.")
                return@launch
            }
            acquireWakeLock()
            playback.start(48_000)
            floor.connecting()
            update { copy(role = RadioRole.CLIENT, state = RadioState.CONNECTING, localNodeId = nodeId, error = null) }
            try {
                val client = ClientControlSession(
                    scope = ioScope,
                    nodeId = nodeId,
                    nodeName = settings.nodeName,
                    hostAddress = address,
                    controlPort = port,
                    pin = pin,
                    onConnected = { connectedRoom, host, audioPort ->
                        floor.connected()
                        update {
                            copy(
                                role = RadioRole.CLIENT,
                                state = RadioState.CONNECTED_IDLE,
                                roomName = connectedRoom,
                                hostName = host,
                                sessionId = clientSession?.sessionId ?: "",
                                localIp = NetworkUtil.localIpv4(),
                                controlPort = port,
                                audioPort = audioPort,
                                error = null
                            )
                        }
                    },
                    onPeers = { peers -> update { copy(peers = peers) } },
                    onFloorGranted = { onFloorGranted() },
                    onFloorDenied = { speaker ->
                        floor.deny(speaker)
                        update { copy(state = floor.state, currentSpeaker = speaker) }
                    },
                    onSpeaker = { speaker -> onSpeakerChanged(speaker) },
                    onPacket = { packet -> receiveAudio(packet) },
                    onDisconnected = { reason ->
                        fail(reason ?: "Disconnected from host")
                    }
                )
                clientSession = client
                client.start()
                update { copy(sessionId = client.sessionId, audioPort = client.localAudioPort) }
            } catch (e: Exception) {
                fail(e.message ?: "Connection failed")
            }
        }
    }

    fun pttDown() {
        val action = floor.pressPtt()
        update { copy(state = floor.state) }
        if (action != FloorAction.REQUEST_FLOOR) return
        when (status.role) {
            RadioRole.HOST -> serviceScope.launch {
                val granted = hostSession?.localFloorRequest(nodeId) == true
                if (granted) onFloorGranted() else {
                    floor.deny(status.currentSpeaker)
                    update { copy(state = floor.state) }
                }
            }
            RadioRole.CLIENT -> clientSession?.requestFloor()
            else -> Unit
        }
    }

    fun pttUp() {
        val action = floor.releasePtt()
        audioCapture.stop()
        playback.setMuted(false)
        stopRenewing()
        if (action == FloorAction.STOP_AND_RELEASE || action == FloorAction.RELEASE_FLOOR) {
            when (status.role) {
                RadioRole.HOST -> hostSession?.localFloorRelease(nodeId)
                RadioRole.CLIENT -> clientSession?.releaseFloor()
                else -> Unit
            }
        }
        update { copy(state = floor.state, currentSpeaker = null) }
    }

    fun showOverlay() {
        overlay?.show(settings.overlaySizeDp)
        overlay?.update(floor.state)
    }

    fun stopRadio(keepForeground: Boolean = false) {
        pttUp()
        discovery?.stop()
        discovery = null
        advertiser.stop()
        hostSession?.close()
        clientSession?.close()
        hostSession = null
        clientSession = null
        overlay?.remove()
        playback.close()
        playback = AudioPlaybackPipeline(ioScope)
        stopRenewing()
        releaseWakeLock()
        floor.disconnected()
        update {
            RoomStatus(
                role = RadioRole.NONE,
                state = RadioState.DISCONNECTED,
                localNodeId = nodeId,
                diagnostics = counters.snapshot()
            )
        }
        if (!keepForeground) stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun onFloorGranted() {
        val action = floor.grant(nodeId)
        if (action == FloorAction.START_CAPTURE) {
            val sessionUuid = hostSession?.sessionUuid ?: clientSession?.sessionUuid ?: return
            playback.setMuted(true)
            startRenewing()
            audioCapture.start(sessionUuid, NetworkUtil.nodeNumericId(nodeId), streamCounter++)
        } else if (action == FloorAction.RELEASE_FLOOR) {
            when (status.role) {
                RadioRole.HOST -> hostSession?.localFloorRelease(nodeId)
                RadioRole.CLIENT -> clientSession?.releaseFloor()
                else -> Unit
            }
        }
        update { copy(state = floor.state, currentSpeaker = floor.currentSpeaker) }
    }

    private fun onSpeakerChanged(speaker: String?) {
        if (speaker == null) floor.remoteSpeakerEnded()
        else if (speaker != nodeId) floor.remoteSpeakerStarted(speaker)
        update { copy(state = floor.state, currentSpeaker = speaker) }
        overlay?.update(floor.state)
    }

    private fun receiveAudio(packet: UdpAudioPacket) {
        counters.received()
        playback.play(packet)
        counters.jitterDepth(playback.jitterDepth)
        update()
    }

    private suspend fun sendAudioPacket(packet: UdpAudioPacket) {
        val bytes = packet.encode()
        when (status.role) {
            RadioRole.HOST -> hostSession?.sendFromLocal(bytes, bytes.size)
            RadioRole.CLIENT -> clientSession?.sendAudio(bytes, bytes.size)
            else -> Unit
        }
        counters.sent()
    }

    private fun startRenewing() {
        stopRenewing()
        renewJob = serviceScope.launch {
            while (true) {
                delay(HostControlSession.RENEW_MS)
                when (status.role) {
                    RadioRole.HOST -> hostSession?.localFloorRenew(nodeId)
                    RadioRole.CLIENT -> clientSession?.renewFloor()
                    else -> Unit
                }
            }
        }
    }

    private fun stopRenewing() {
        renewJob?.cancel()
        renewJob = null
    }

    private fun fail(message: String) {
        audioCapture.stop()
        playback.setMuted(false)
        stopRenewing()
        floor.error()
        update { copy(state = RadioState.ERROR, error = message) }
    }

    private fun update(transform: RoomStatus.() -> RoomStatus = { this }) {
        status = status.copy(
            localNodeId = nodeId,
            diagnostics = counters.snapshot()
        ).transform()
        overlay?.update(status.state)
        listeners.forEach { it.onStatus(status) }
        runCatching {
            val manager = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.notify(RadioNotificationFactory.NOTIFICATION_ID, notifications.build(status))
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LocalPTT:radio").apply {
            setReferenceCounted(false)
            acquire(60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        wakeLock = null
    }

    override fun onDestroy() {
        stopRadio()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.localptt.radio.START"
        const val ACTION_STOP = "com.localptt.radio.STOP"
    }
}
