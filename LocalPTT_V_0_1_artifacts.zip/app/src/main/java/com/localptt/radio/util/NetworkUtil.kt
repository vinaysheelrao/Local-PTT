package com.localptt.radio.util

import java.net.Inet4Address
import java.net.NetworkInterface

object NetworkUtil {
    fun localIpv4(): String {
        val interfaces = NetworkInterface.getNetworkInterfaces().toList()
        for (iface in interfaces) {
            if (!iface.isUp || iface.isLoopback) continue
            for (addr in iface.inetAddresses.toList()) {
                if (addr is Inet4Address && !addr.isLoopbackAddress) return addr.hostAddress ?: ""
            }
        }
        return "0.0.0.0"
    }

    fun nodeNumericId(nodeId: String): Long {
        var result = 1125899906842597L
        nodeId.forEach { result = 31 * result + it.code }
        return result
    }
}
