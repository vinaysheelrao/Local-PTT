package com.localptt.radio.network.control

import org.json.JSONObject
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID

data class ControlMessage(
    val protocolVersion: Int = ControlProtocol.PROTOCOL_VERSION,
    val messageType: MessageType,
    val messageId: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val senderNodeId: String,
    val sessionId: String,
    val payload: JSONObject = JSONObject()
) {
    fun toJson(): JSONObject = JSONObject()
        .put("protocolVersion", protocolVersion)
        .put("messageType", messageType.name)
        .put("messageId", messageId)
        .put("timestamp", timestamp)
        .put("senderNodeId", senderNodeId)
        .put("sessionId", sessionId)
        .put("payload", payload)

    companion object {
        fun fromJson(json: JSONObject): ControlMessage {
            val version = json.optInt("protocolVersion", -1)
            require(version == ControlProtocol.PROTOCOL_VERSION) { "Unsupported protocol version" }
            val typeName = bounded(json.getString("messageType"), 40, "messageType")
            val messageId = bounded(json.getString("messageId"), 80, "messageId")
            val sender = bounded(json.getString("senderNodeId"), 64, "senderNodeId")
            val session = bounded(json.getString("sessionId"), 80, "sessionId")
            return ControlMessage(
                protocolVersion = version,
                messageType = MessageType.valueOf(typeName),
                messageId = messageId,
                timestamp = json.getLong("timestamp"),
                senderNodeId = sender,
                sessionId = session,
                payload = json.optJSONObject("payload") ?: JSONObject()
            )
        }

        private fun bounded(value: String, max: Int, name: String): String {
            require(value.length <= max) { "$name too long" }
            return value
        }
    }
}

object ControlProtocol {
    const val PROTOCOL_VERSION = 1
    const val MAX_FRAME_BYTES = 32 * 1024
    const val MAX_ROOM_NAME = 40
    const val MAX_NODE_NAME = 32

    fun encode(message: ControlMessage): ByteArray {
        val body = message.toJson().toString().toByteArray(Charsets.UTF_8)
        require(body.size <= MAX_FRAME_BYTES) { "Control frame too large" }
        return ByteBuffer.allocate(4 + body.size)
            .order(ByteOrder.BIG_ENDIAN)
            .putInt(body.size)
            .put(body)
            .array()
    }

    fun write(output: OutputStream, message: ControlMessage) {
        output.write(encode(message))
        output.flush()
    }

    fun read(input: InputStream): ControlMessage {
        val header = input.readExact(4)
        val length = ByteBuffer.wrap(header).order(ByteOrder.BIG_ENDIAN).int
        require(length in 1..MAX_FRAME_BYTES) { "Invalid control frame length" }
        val body = input.readExact(length)
        val text = body.toString(Charsets.UTF_8)
        val json = try {
            JSONObject(text)
        } catch (e: Exception) {
            throw IllegalArgumentException("Invalid JSON control frame", e)
        }
        return ControlMessage.fromJson(json)
    }

    private fun InputStream.readExact(length: Int): ByteArray {
        val out = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val read = read(out, offset, length - offset)
            if (read < 0) throw EOFException("Stream closed")
            offset += read
        }
        return out
    }
}
