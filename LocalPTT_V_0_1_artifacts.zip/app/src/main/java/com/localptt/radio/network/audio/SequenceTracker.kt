package com.localptt.radio.network.audio

class SequenceTracker(private val window: Long = 256) {
    private var initialized = false
    private var highest = 0L
    private val recent = LinkedHashSet<Long>()

    fun accept(sequence: Long): SequenceDecision {
        val seq = sequence and 0xFFFF_FFFFL
        if (!initialized) {
            initialized = true
            highest = seq
            remember(seq)
            return SequenceDecision.ACCEPT
        }
        if (recent.contains(seq)) return SequenceDecision.DUPLICATE
        val forward = distanceForward(highest, seq)
        val backward = distanceForward(seq, highest)
        return when {
            forward in 1..window -> {
                highest = seq
                remember(seq)
                SequenceDecision.ACCEPT
            }
            backward in 1..window -> {
                remember(seq)
                SequenceDecision.ACCEPT_OUT_OF_ORDER
            }
            forward > window -> SequenceDecision.TOO_FAR_AHEAD
            else -> SequenceDecision.TOO_LATE
        }
    }

    fun reset() {
        initialized = false
        highest = 0
        recent.clear()
    }

    private fun remember(seq: Long) {
        recent.add(seq)
        while (recent.size > window) {
            val iterator = recent.iterator()
            if (iterator.hasNext()) {
                iterator.next()
                iterator.remove()
            }
        }
    }

    private fun distanceForward(from: Long, to: Long): Long = (to - from) and 0xFFFF_FFFFL
}

enum class SequenceDecision {
    ACCEPT,
    ACCEPT_OUT_OF_ORDER,
    DUPLICATE,
    TOO_LATE,
    TOO_FAR_AHEAD
}
