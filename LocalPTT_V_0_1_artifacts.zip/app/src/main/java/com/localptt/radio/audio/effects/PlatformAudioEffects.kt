package com.localptt.radio.audio.effects

import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor

class PlatformAudioEffects(
    private val audioSessionId: Int,
    private val enableNoise: Boolean,
    private val enableEcho: Boolean,
    private val enableGain: Boolean
) : AutoCloseable {
    private var noiseSuppressor: NoiseSuppressor? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var gainControl: AutomaticGainControl? = null

    fun attach() {
        if (enableNoise && NoiseSuppressor.isAvailable()) {
            runCatching {
                noiseSuppressor = NoiseSuppressor.create(audioSessionId)?.apply { enabled = true }
            }
        }
        if (enableEcho && AcousticEchoCanceler.isAvailable()) {
            runCatching {
                echoCanceler = AcousticEchoCanceler.create(audioSessionId)?.apply { enabled = true }
            }
        }
        if (enableGain && AutomaticGainControl.isAvailable()) {
            runCatching {
                gainControl = AutomaticGainControl.create(audioSessionId)?.apply { enabled = true }
            }
        }
    }

    override fun close() {
        runCatching { noiseSuppressor?.release() }
        runCatching { echoCanceler?.release() }
        runCatching { gainControl?.release() }
        noiseSuppressor = null
        echoCanceler = null
        gainControl = null
    }
}
