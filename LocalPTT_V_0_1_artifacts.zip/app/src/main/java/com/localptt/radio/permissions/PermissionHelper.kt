package com.localptt.radio.permissions

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings

object PermissionHelper {
    const val ACCESS_LOCAL_NETWORK = "android.permission.ACCESS_LOCAL_NETWORK"

    fun requiredRuntimePermissions(): Array<String> {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT >= 37) permissions += ACCESS_LOCAL_NETWORK
        return permissions.toTypedArray()
    }

    fun missing(context: Context): List<String> = requiredRuntimePermissions().filter {
        context.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
    }

    fun statusText(context: Context): String {
        val missing = missing(context)
        return if (missing.isEmpty()) "Permissions: ready"
        else "Permissions needed: " + missing.joinToString { it.substringAfterLast('.') }
    }

    fun request(activity: Activity, requestCode: Int) {
        val missing = missing(activity)
        if (missing.isNotEmpty()) activity.requestPermissions(missing.toTypedArray(), requestCode)
    }

    fun overlayIntent(context: Context): Intent = Intent(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        Uri.parse("package:${context.packageName}")
    )

    fun canDrawOverlay(context: Context): Boolean =
        Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context)
}
