package com.localptt.radio.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.Toast
import android.app.Activity
import com.localptt.radio.databinding.ActivityMainBinding
import com.localptt.radio.permissions.PermissionHelper
import com.localptt.radio.room.DiscoveredRoom
import com.localptt.radio.room.RadioRole
import com.localptt.radio.room.RoomStatus
import com.localptt.radio.service.RadioForegroundService
import com.localptt.radio.settings.RadioSettings
import com.localptt.radio.settings.SettingsStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), RadioForegroundService.Listener {
    private lateinit var binding: ActivityMainBinding
    private lateinit var settingsStore: SettingsStore
    private var service: RadioForegroundService? = null
    private var bound = false
    private var selectedRoom: DiscoveredRoom? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = (binder as RadioForegroundService.LocalBinder).service()
            bound = true
            service?.addListener(this@MainActivity)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service?.removeListener(this@MainActivity)
            service = null
            bound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        settingsStore = SettingsStore(this)
        renderSettings(settingsStore.load())
        configureActions()
        startAndBindService()
        binding.permissionText.text = PermissionHelper.statusText(this)
    }

    override fun onDestroy() {
        service?.removeListener(this)
        if (bound) unbindService(connection)
        bound = false
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        binding.permissionText.text = PermissionHelper.statusText(this)
    }

    override fun onStatus(status: RoomStatus) {
        runOnUiThread { renderStatus(status) }
    }

    private fun configureActions() {
        binding.createRoomButton.setOnClickListener {
            showCreate()
        }
        binding.joinRoomButton.setOnClickListener {
            showJoin()
            ensurePermissions()
            service?.startDiscovery()
        }
        binding.refreshDiscoveryButton.setOnClickListener {
            ensurePermissions()
            service?.startDiscovery()
        }
        binding.startHostButton.setOnClickListener {
            if (!ensureReady()) return@setOnClickListener
            saveSettingsFromUi()
            service?.createRoom(
                roomName = binding.roomNameInput.text.toString().trim().ifBlank { "LocalPTT" },
                hostName = binding.hostNameInput.text.toString().trim().ifBlank { binding.nodeNameInput.text.toString().trim() },
                openRoom = binding.openRoomCheck.isChecked
            )
        }
        binding.joinSelectedButton.setOnClickListener {
            if (!ensureReady()) return@setOnClickListener
            saveSettingsFromUi()
            val manualPort = binding.manualPortInput.text.toString().toIntOrNull() ?: 0
            service?.joinRoom(
                room = selectedRoom,
                manualHost = binding.manualHostInput.text.toString().trim(),
                manualPort = manualPort,
                pin = binding.pinInput.text.toString().trim()
            )
        }
        binding.leaveButton.setOnClickListener {
            service?.stopRadio()
            showHome()
        }
        binding.overlayButton.setOnClickListener {
            if (PermissionHelper.canDrawOverlay(this)) {
                service?.showOverlay()
            } else {
                startActivity(PermissionHelper.overlayIntent(this))
                Toast.makeText(this, "Enable display over other apps to use floating PTT.", Toast.LENGTH_LONG).show()
            }
        }
        binding.pttButton.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    service?.pttDown()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    service?.pttUp()
                    true
                }
                else -> true
            }
        }
    }

    private fun renderStatus(status: RoomStatus) {
        binding.permissionText.text = PermissionHelper.statusText(this)
        binding.statusText.text = buildString {
            append("State: ${status.state.name}")
            if (status.currentSpeaker != null) append("\nSpeaker: ${status.currentSpeaker}")
            if (status.error != null) append("\nError: ${status.error}")
        }
        binding.roomInfoText.text = buildString {
            append("Room: ${status.roomName.ifBlank { "-" }}")
            append("\nRole: ${status.role}")
            append("\nHost: ${status.hostName.ifBlank { "-" }}")
            append("\nIP: ${status.localIp.ifBlank { "-" }}")
            append("\nControl: ${status.controlPort}  Audio: ${status.audioPort}")
            if (status.pin.isNotBlank()) append("\nPIN: ${status.pin}")
        }
        binding.peerListText.text = if (status.peers.isEmpty()) {
            "Peers: none"
        } else {
            "Peers:\n" + status.peers.joinToString("\n") { "- ${it.nodeName} (${it.nodeId.take(8)})" }
        }
        renderRooms(status.discoveredRooms)
        binding.diagnosticsText.text = diagnosticsText(status)
        if (status.role != RadioRole.NONE) showRadio()
    }

    private fun renderRooms(rooms: List<DiscoveredRoom>) {
        binding.roomList.removeAllViews()
        if (rooms.isEmpty()) {
            val empty = Button(this).apply {
                text = "No rooms found"
                isEnabled = false
            }
            binding.roomList.addView(empty)
            return
        }
        rooms.forEach { room ->
            val button = Button(this).apply {
                text = "${room.roomName} / ${room.hostName} / ${room.hostAddress?.hostAddress ?: "resolving"}:${room.controlPort}"
                setOnClickListener {
                    selectedRoom = room
                    binding.manualHostInput.setText(room.hostAddress?.hostAddress ?: "")
                    binding.manualPortInput.setText(room.controlPort.toString())
                    Toast.makeText(this@MainActivity, "Selected ${room.roomName}", Toast.LENGTH_SHORT).show()
                }
            }
            binding.roomList.addView(button)
        }
    }

    private fun diagnosticsText(status: RoomStatus): String {
        val df = SimpleDateFormat("HH:mm:ss", Locale.US)
        val lastHeartbeat = if (status.diagnostics.lastHeartbeat > 0) df.format(Date(status.diagnostics.lastHeartbeat)) else "-"
        return """
            Diagnostics
            Role: ${status.role}
            State: ${status.state}
            Host IP: ${status.localIp.ifBlank { "-" }}
            Control port: ${status.controlPort}
            Audio port: ${status.audioPort}
            Sample rate: ${status.diagnostics.selectedSampleRate}
            Opus bitrate: ${status.diagnostics.opusBitrate}
            Peers: ${status.peers.size}
            Last heartbeat: $lastHeartbeat
            Packets sent: ${status.diagnostics.packetsSent}
            Packets received: ${status.diagnostics.packetsReceived}
            Packets dropped: ${status.diagnostics.packetsDropped}
            Jitter depth: ${status.diagnostics.jitterDepth}
            Reconnects: ${status.diagnostics.reconnectCount}
        """.trimIndent()
    }

    private fun renderSettings(settings: RadioSettings) {
        binding.nodeNameInput.setText(settings.nodeName)
        binding.hostNameInput.setText(settings.nodeName)
        binding.noiseCheck.isChecked = settings.noiseSuppression
        binding.echoCheck.isChecked = settings.echoCancellation
        binding.gainCheck.isChecked = settings.automaticGain
        binding.hapticCheck.isChecked = settings.haptics
        binding.deviceNameText.text = "Node: ${settings.nodeName}"
    }

    private fun saveSettingsFromUi() {
        val current = settingsStore.load()
        val settings = current.copy(
            nodeName = binding.nodeNameInput.text.toString().trim().ifBlank { current.nodeName }.take(32),
            noiseSuppression = binding.noiseCheck.isChecked,
            echoCancellation = binding.echoCheck.isChecked,
            automaticGain = binding.gainCheck.isChecked,
            haptics = binding.hapticCheck.isChecked
        )
        settingsStore.save(settings)
        service?.saveSettings(settings)
        binding.deviceNameText.text = "Node: ${settings.nodeName}"
    }

    private fun ensureReady(): Boolean {
        startAndBindService()
        if (!ensurePermissions()) return false
        return true
    }

    private fun ensurePermissions(): Boolean {
        val missing = PermissionHelper.missing(this)
        if (missing.isNotEmpty()) {
            PermissionHelper.request(this, REQUEST_PERMISSIONS)
            return false
        }
        return true
    }

    private fun startAndBindService() {
        val intent = Intent(this, RadioForegroundService::class.java).setAction(RadioForegroundService.ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        if (!bound) bindService(Intent(this, RadioForegroundService::class.java), connection, Context.BIND_AUTO_CREATE)
    }

    private fun showHome() {
        binding.homePanel.visibility = View.VISIBLE
        binding.createPanel.visibility = View.GONE
        binding.joinPanel.visibility = View.GONE
        binding.radioPanel.visibility = View.GONE
    }

    private fun showCreate() {
        binding.homePanel.visibility = View.GONE
        binding.createPanel.visibility = View.VISIBLE
        binding.joinPanel.visibility = View.GONE
        binding.radioPanel.visibility = View.GONE
    }

    private fun showJoin() {
        binding.homePanel.visibility = View.GONE
        binding.createPanel.visibility = View.GONE
        binding.joinPanel.visibility = View.VISIBLE
        binding.radioPanel.visibility = View.GONE
    }

    private fun showRadio() {
        binding.homePanel.visibility = View.GONE
        binding.createPanel.visibility = View.GONE
        binding.joinPanel.visibility = View.GONE
        binding.radioPanel.visibility = View.VISIBLE
    }

    companion object {
        private const val REQUEST_PERMISSIONS = 7001
    }
}
