#include <jni.h>
#include <opus.h>
#include <vector>

extern "C" JNIEXPORT jlong JNICALL
Java_com_localptt_radio_audio_codec_NativeOpus_createEncoder(
    JNIEnv *, jobject, jint sampleRate, jint channels, jint bitrate) {
    int err = OPUS_OK;
    OpusEncoder *encoder = opus_encoder_create(sampleRate, channels, OPUS_APPLICATION_VOIP, &err);
    if (err != OPUS_OK || encoder == nullptr) return 0;
    opus_encoder_ctl(encoder, OPUS_SET_BITRATE(bitrate));
    opus_encoder_ctl(encoder, OPUS_SET_VBR(1));
    opus_encoder_ctl(encoder, OPUS_SET_INBAND_FEC(1));
    opus_encoder_ctl(encoder, OPUS_SET_PACKET_LOSS_PERC(10));
    opus_encoder_ctl(encoder, OPUS_SET_SIGNAL(OPUS_SIGNAL_VOICE));
    return reinterpret_cast<jlong>(encoder);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_localptt_radio_audio_codec_NativeOpus_encode(
    JNIEnv *env, jobject, jlong handle, jshortArray pcm, jint pcmOffset, jint frameSize,
    jbyteArray output, jint outputOffset, jint maxBytes) {
    auto *encoder = reinterpret_cast<OpusEncoder *>(handle);
    if (encoder == nullptr) return OPUS_BAD_ARG;
    jshort *pcmPtr = env->GetShortArrayElements(pcm, nullptr);
    jbyte *outPtr = env->GetByteArrayElements(output, nullptr);
    int result = opus_encode(
        encoder,
        reinterpret_cast<const opus_int16 *>(pcmPtr + pcmOffset),
        frameSize,
        reinterpret_cast<unsigned char *>(outPtr + outputOffset),
        maxBytes);
    env->ReleaseShortArrayElements(pcm, pcmPtr, JNI_ABORT);
    env->ReleaseByteArrayElements(output, outPtr, 0);
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_localptt_radio_audio_codec_NativeOpus_destroyEncoder(
    JNIEnv *, jobject, jlong handle) {
    auto *encoder = reinterpret_cast<OpusEncoder *>(handle);
    if (encoder != nullptr) opus_encoder_destroy(encoder);
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_localptt_radio_audio_codec_NativeOpus_createDecoder(
    JNIEnv *, jobject, jint sampleRate, jint channels) {
    int err = OPUS_OK;
    OpusDecoder *decoder = opus_decoder_create(sampleRate, channels, &err);
    if (err != OPUS_OK || decoder == nullptr) return 0;
    return reinterpret_cast<jlong>(decoder);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_localptt_radio_audio_codec_NativeOpus_decode(
    JNIEnv *env, jobject, jlong handle, jbyteArray packet, jint packetOffset, jint packetLength,
    jshortArray pcm, jint pcmOffset, jint frameSize, jboolean fec) {
    auto *decoder = reinterpret_cast<OpusDecoder *>(handle);
    if (decoder == nullptr) return OPUS_BAD_ARG;
    jbyte *packetPtr = packetLength > 0 ? env->GetByteArrayElements(packet, nullptr) : nullptr;
    jshort *pcmPtr = env->GetShortArrayElements(pcm, nullptr);
    const unsigned char *payload = packetLength > 0
        ? reinterpret_cast<const unsigned char *>(packetPtr + packetOffset)
        : nullptr;
    int result = opus_decode(
        decoder,
        payload,
        packetLength,
        reinterpret_cast<opus_int16 *>(pcmPtr + pcmOffset),
        frameSize,
        fec ? 1 : 0);
    if (packetPtr != nullptr) env->ReleaseByteArrayElements(packet, packetPtr, JNI_ABORT);
    env->ReleaseShortArrayElements(pcm, pcmPtr, 0);
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_localptt_radio_audio_codec_NativeOpus_destroyDecoder(
    JNIEnv *, jobject, jlong handle) {
    auto *decoder = reinterpret_cast<OpusDecoder *>(handle);
    if (decoder != nullptr) opus_decoder_destroy(decoder);
}
